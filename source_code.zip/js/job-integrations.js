/**
 * Job Integrations Module
 * 
 * This module handles integration with external job platforms:
 * - LinkedIn
 * - JobsDB
 * - Indeed
 * - Glassdoor
 * - Monster
 * 
 * The API endpoints are simulated for demonstration purposes.
 */

// Main job integrations controller
class JobIntegrations {
    constructor() {
        this.apiEndpoints = {
            linkedin: 'https://api.linkedin.com/v2/jobs',
            jobsdb: 'https://api.jobsdb.com/v1/jobs',
            indeed: 'https://api.indeed.com/v2/jobs',
            glassdoor: 'https://api.glassdoor.com/v1/jobs',
            monster: 'https://api.monster.com/v2/jobs'
        };
        
        this.apiKeys = {
            linkedin: 'simulated-linkedin-api-key',
            jobsdb: 'simulated-jobsdb-api-key',
            indeed: 'simulated-indeed-api-key',
            glassdoor: 'simulated-glassdoor-api-key',
            monster: 'simulated-monster-api-key'
        };
        
        this.cachedJobs = {
            linkedin: [],
            jobsdb: [],
            indeed: [],
            glassdoor: [],
            monster: []
        };
        
        this.lastFetch = {
            linkedin: null,
            jobsdb: null,
            indeed: null,
            glassdoor: null,
            monster: null
        };
        
        // Cache expiration time (15 minutes)
        this.cacheExpirationTime = 15 * 60 * 1000;
    }
    
    /**
     * Get jobs from all integrated platforms
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} Combined job listings
     */
    async getAllJobs(filters = {}) {
        try {
            const [linkedinJobs, jobsdbJobs, indeedJobs, glassdoorJobs, monsterJobs] = await Promise.all([
                this.getLinkedInJobs(filters),
                this.getJobsDBJobs(filters),
                this.getIndeedJobs(filters),
                this.getGlassdoorJobs(filters),
                this.getMonsterJobs(filters)
            ]);
            
            // Combine and remove duplicates
            const allJobs = [
                ...linkedinJobs,
                ...jobsdbJobs,
                ...indeedJobs,
                ...glassdoorJobs,
                ...monsterJobs
            ];
            
            // Remove potential duplicates by title+company combination
            const uniqueJobs = this.removeDuplicateJobs(allJobs);
            
            return uniqueJobs;
        } catch (error) {
            console.error('Error fetching jobs from all sources:', error);
            return [];
        }
    }
    
    /**
     * Remove duplicate jobs based on title and company
     * @param {Array} jobs - Array of job listings
     * @returns {Array} Deduplicated job listings
     */
    removeDuplicateJobs(jobs) {
        const uniqueMap = new Map();
        
        jobs.forEach(job => {
            const key = `${job.title.toLowerCase()}-${job.company.toLowerCase()}`;
            
            // If this is a new unique job or has a higher relevance score than existing one
            if (!uniqueMap.has(key) || uniqueMap.get(key).relevanceScore < job.relevanceScore) {
                uniqueMap.set(key, job);
            }
        });
        
        return Array.from(uniqueMap.values());
    }
    
    /**
     * Check if cache is valid
     * @param {string} source - API source name
     * @returns {boolean} Whether cache is valid
     */
    isCacheValid(source) {
        if (!this.lastFetch[source]) return false;
        
        const now = new Date().getTime();
        const timeSinceLastFetch = now - this.lastFetch[source];
        
        return timeSinceLastFetch < this.cacheExpirationTime;
    }
    
    /**
     * Get jobs from LinkedIn
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} LinkedIn job listings
     */
    async getLinkedInJobs(filters = {}) {
        // Return cached data if valid
        if (this.isCacheValid('linkedin')) {
            return this.filterJobs(this.cachedJobs.linkedin, filters);
        }
        
        try {
            // In real implementation, this would make an API call to LinkedIn
            // For demonstration, we'll use simulated data
            const response = await this.simulateApiCall('linkedin', filters);
            
            // Cache the results
            this.cachedJobs.linkedin = response;
            this.lastFetch.linkedin = new Date().getTime();
            
            return this.filterJobs(response, filters);
        } catch (error) {
            console.error('Error fetching LinkedIn jobs:', error);
            return [];
        }
    }
    
    /**
     * Get jobs from JobsDB
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} JobsDB job listings
     */
    async getJobsDBJobs(filters = {}) {
        // Return cached data if valid
        if (this.isCacheValid('jobsdb')) {
            return this.filterJobs(this.cachedJobs.jobsdb, filters);
        }
        
        try {
            // In real implementation, this would make an API call to JobsDB
            // For demonstration, we'll use simulated data
            const response = await this.simulateApiCall('jobsdb', filters);
            
            // Cache the results
            this.cachedJobs.jobsdb = response;
            this.lastFetch.jobsdb = new Date().getTime();
            
            return this.filterJobs(response, filters);
        } catch (error) {
            console.error('Error fetching JobsDB jobs:', error);
            return [];
        }
    }
    
    /**
     * Get jobs from Indeed
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} Indeed job listings
     */
    async getIndeedJobs(filters = {}) {
        // Return cached data if valid
        if (this.isCacheValid('indeed')) {
            return this.filterJobs(this.cachedJobs.indeed, filters);
        }
        
        try {
            // In real implementation, this would make an API call to Indeed
            // For demonstration, we'll use simulated data
            const response = await this.simulateApiCall('indeed', filters);
            
            // Cache the results
            this.cachedJobs.indeed = response;
            this.lastFetch.indeed = new Date().getTime();
            
            return this.filterJobs(response, filters);
        } catch (error) {
            console.error('Error fetching Indeed jobs:', error);
            return [];
        }
    }
    
    /**
     * Get jobs from Glassdoor
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} Glassdoor job listings
     */
    async getGlassdoorJobs(filters = {}) {
        // Return cached data if valid
        if (this.isCacheValid('glassdoor')) {
            return this.filterJobs(this.cachedJobs.glassdoor, filters);
        }
        
        try {
            // In real implementation, this would make an API call to Glassdoor
            // For demonstration, we'll use simulated data
            const response = await this.simulateApiCall('glassdoor', filters);
            
            // Cache the results
            this.cachedJobs.glassdoor = response;
            this.lastFetch.glassdoor = new Date().getTime();
            
            return this.filterJobs(response, filters);
        } catch (error) {
            console.error('Error fetching Glassdoor jobs:', error);
            return [];
        }
    }
    
    /**
     * Get jobs from Monster
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} Monster job listings
     */
    async getMonsterJobs(filters = {}) {
        // Return cached data if valid
        if (this.isCacheValid('monster')) {
            return this.filterJobs(this.cachedJobs.monster, filters);
        }
        
        try {
            // In real implementation, this would make an API call to Monster
            // For demonstration, we'll use simulated data
            const response = await this.simulateApiCall('monster', filters);
            
            // Cache the results
            this.cachedJobs.monster = response;
            this.lastFetch.monster = new Date().getTime();
            
            return this.filterJobs(response, filters);
        } catch (error) {
            console.error('Error fetching Monster jobs:', error);
            return [];
        }
    }
    
    /**
     * Apply filters to job listings
     * @param {Array} jobs - Job listings
     * @param {Object} filters - Search filters
     * @returns {Array} Filtered job listings
     */
    filterJobs(jobs, filters) {
        if (!filters || Object.keys(filters).length === 0) {
            return jobs;
        }
        
        return jobs.filter(job => {
            // Apply location filter
            if (filters.location && job.location) {
                // Simple contains check (in real app, would use more sophisticated location matching)
                if (!job.location.toLowerCase().includes(filters.location.toLowerCase())) {
                    return false;
                }
            }
            
            // Apply job title/keyword filter
            if (filters.keyword && (job.title || job.description)) {
                const keywordLower = filters.keyword.toLowerCase();
                const titleMatch = job.title && job.title.toLowerCase().includes(keywordLower);
                const descMatch = job.description && job.description.toLowerCase().includes(keywordLower);
                
                if (!titleMatch && !descMatch) {
                    return false;
                }
            }
            
            // Apply job type filter
            if (filters.jobType && job.type) {
                if (job.type.toLowerCase() !== filters.jobType.toLowerCase()) {
                    return false;
                }
            }
            
            // Apply experience level filter
            if (filters.experienceLevel && job.experienceLevel) {
                if (job.experienceLevel.toLowerCase() !== filters.experienceLevel.toLowerCase()) {
                    return false;
                }
            }
            
            // Apply salary range filter
            if (filters.minSalary && job.salaryMin) {
                if (job.salaryMin < filters.minSalary) {
                    return false;
                }
            }
            
            if (filters.maxSalary && job.salaryMax) {
                if (job.salaryMax > filters.maxSalary) {
                    return false;
                }
            }
            
            return true;
        });
    }
    
    /**
     * Simulate API call with sample data
     * @param {string} source - API source
     * @param {Object} filters - Search filters
     * @returns {Promise<Array>} Simulated job listings
     */
    async simulateApiCall(source, filters) {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Generate different sample data for each source
        const sampleData = this.generateSampleJobs(source, 20);
        
        return sampleData;
    }
    
    /**
     * Generate sample jobs for demonstration
     * @param {string} source - Job source
     * @param {number} count - Number of jobs to generate
     * @returns {Array} Sample job listings
     */
    generateSampleJobs(source, count) {
        const jobs = [];
        
        // Job titles pool
        const jobTitles = [
            'Software Engineer', 'Frontend Developer', 'Backend Developer',
            'UX Designer', 'Product Manager', 'Data Scientist',
            'DevOps Engineer', 'QA Engineer', 'Marketing Specialist',
            'Sales Representative', 'HR Manager', 'Financial Analyst',
            'Project Manager', 'Business Analyst', 'Content Writer',
            'SEO Specialist', 'UI Designer', 'System Administrator',
            'Mobile Developer', 'Cloud Architect'
        ];
        
        // Companies pool with source prefix for distinction
        const companies = [
            `${this.capitalizeFirstLetter(source)} Tech Solutions`,
            `${this.capitalizeFirstLetter(source)} Global Inc.`,
            `${this.capitalizeFirstLetter(source)} Innovations`,
            `${this.capitalizeFirstLetter(source)} Digital Group`,
            `${this.capitalizeFirstLetter(source)} Systems`
        ];
        
        // Locations
        const locations = [
            'กรุงเทพมหานคร', 'นนทบุรี', 'ปทุมธานี', 'เชียงใหม่',
            'ขอนแก่น', 'ภูเก็ต', 'ชลบุรี', 'ระยอง', 'สงขลา', 'อยุธยา'
        ];
        
        // Job types
        const jobTypes = ['full-time', 'part-time', 'contract', 'remote'];
        
        // Experience levels
        const expLevels = ['entry', 'junior', 'mid', 'senior', 'expert'];
        
        for (let i = 0; i < count; i++) {
            const titleIndex = Math.floor(Math.random() * jobTitles.length);
            const companyIndex = Math.floor(Math.random() * companies.length);
            const locationIndex = Math.floor(Math.random() * locations.length);
            const typeIndex = Math.floor(Math.random() * jobTypes.length);
            const expIndex = Math.floor(Math.random() * expLevels.length);
            
            // Generate random salary range based on experience level
            const baseSalary = 25000;
            const expMultiplier = expIndex + 1;
            const salaryMin = baseSalary * expMultiplier;
            const salaryMax = salaryMin * (1.2 + Math.random() * 0.5);
            
            // Create job object
            const job = {
                id: `${source}-${i + 1}`,
                title: jobTitles[titleIndex],
                company: companies[companyIndex],
                location: locations[locationIndex],
                type: jobTypes[typeIndex],
                experienceLevel: expLevels[expIndex],
                salaryMin: Math.round(salaryMin),
                salaryMax: Math.round(salaryMax),
                description: `This is a sample ${jobTitles[titleIndex]} position at ${companies[companyIndex]} located in ${locations[locationIndex]}.`,
                requirements: [
                    'Relevant education background',
                    `${expIndex + 1}-${expIndex + 3} years of experience`,
                    'Strong communication skills',
                    'Team player'
                ],
                benefits: [
                    'Competitive salary',
                    'Health insurance',
                    'Annual bonus',
                    'Professional development'
                ],
                postedDate: this.getRandomDate(30), // Within last 30 days
                source: source,
                url: `https://www.${source}.com/jobs/${i + 1}`,
                relevanceScore: Math.random() * 100 // Random relevance score for demo
            };
            
            jobs.push(job);
        }
        
        return jobs;
    }
    
    /**
     * Get random date within last N days
     * @param {number} days - Number of days back
     * @returns {string} ISO date string
     */
    getRandomDate(days) {
        const today = new Date();
        const randomDaysAgo = Math.floor(Math.random() * days);
        const date = new Date(today.getTime() - randomDaysAgo * 24 * 60 * 60 * 1000);
        return date.toISOString().split('T')[0];
    }
    
    /**
     * Capitalize first letter of string
     * @param {string} string - Input string
     * @returns {string} Capitalized string
     */
    capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
}

// Create global instance
const jobIntegrations = new JobIntegrations();