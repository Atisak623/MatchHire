// Jobs Management Functions
document.addEventListener('DOMContentLoaded', function() {
    // Initialize sample jobs if not exists
    initializeSampleJobs();
    
    // Initialize sample applications if not exists
    if (!localStorage.getItem('jobApplications')) {
        localStorage.setItem('jobApplications', JSON.stringify([]));
    }
    
    // If on jobs.html page, fetch jobs from external platforms
    if (window.location.pathname.includes('jobs.html')) {
        fetchExternalJobs();
    }
});

// Initialize sample jobs
function initializeSampleJobs() {
    if (!localStorage.getItem('jobs')) {
        const sampleJobs = [
            {
                id: '1',
                title: 'Frontend Developer',
                company: 'TechStart Co., Ltd.',
                location: 'กรุงเทพมหานคร',
                type: 'full-time',
                category: 'IT',
                salary: '35,000 - 50,000',
                description: 'รับสมัคร Frontend Developer ที่มีประสบการณ์ใน React, Vue.js หรือ Angular',
                requirements: ['ปริญญาตรี สาขาคอมพิวเตอร์ หรือสาขาที่เกี่ยวข้อง', 'ประสบการณ์ 2-3 ปี ในการพัฒนา Frontend', 'มีความรู้ HTML, CSS, JavaScript', 'มีประสบการณ์ React หรือ Vue.js'],
                benefits: ['เงินเดือนตามความสามารถ', 'ประกันสังคม + ประกันสุขภาพ', 'โบนัสประจำปี', 'วันหยุดพักผ่อนประจำปี 15 วัน'],
                postedDate: '2025-05-20'
            },
            {
                id: '2',
                title: 'Digital Marketing Specialist',
                company: 'Creative Agency Ltd.',
                location: 'กรุงเทพมหานคร',
                type: 'full-time',
                category: 'Marketing',
                salary: '30,000 - 45,000',
                description: 'รับสมัครผู้เชี่ยวชาญด้าน Digital Marketing สำหรับทำ campaign ออนไลน์',
                requirements: ['ปริญญาตรี สาขาการตลาด หรือสาขาที่เกี่ยวข้อง', 'ประสบการณ์ 1-2 ปี ในงาน Digital Marketing', 'มีความรู้ Google Ads, Facebook Ads', 'มีทักษะการวิเคราะห์ข้อมูล'],
                benefits: ['ค่าคอมมิชชั่นพิเศษ', 'ประกันสุขภาพกลุ่ม', 'อบรมเพิ่มทักษะ', 'ที่จอดรถฟรี'],
                postedDate: '2025-05-18'
            },
            {
                id: '3',
                title: 'Backend Developer (Node.js)',
                company: 'Innovative Solutions Inc.',
                location: 'นนทบุรี',
                type: 'full-time',
                category: 'IT',
                salary: '40,000 - 60,000',
                description: 'รับสมัคร Backend Developer ที่มีความเชี่ยวชาญใน Node.js และ Database',
                requirements: ['ปริญญาตรี สาขาคอมพิวเตอร์ หรือสาขาที่เกี่ยวข้อง', 'ประสบการณ์ 3+ ปี ในการพัฒนา Backend', 'มีความรู้ Node.js, Express.js', 'มีประสบการณ์ MongoDB, PostgreSQL'],
                benefits: ['เงินเดือนสูง', 'Work from Home 2 วัน/สัปดาห์', 'โบนัสโครงการ', 'อุปกรณ์คอมพิวเตอร์ล่าสุด'],
                postedDate: '2025-05-22'
            },
            {
                id: '4',
                title: 'Sales Executive',
                company: 'Global Trading Co.',
                location: 'กรุงเทพมหานคร',
                type: 'full-time',
                category: 'Sales',
                salary: '25,000 + Commission',
                description: 'รับสมัครพนักงานขายที่มีทักษะการสื่อสารและการเจรจาต่อรองที่ดี',
                requirements: ['ปริญญาตรี ทุกสาขา', 'มีประสบการณ์การขาย 1-2 ปี', 'มีทักษะการสื่อสารที่ดี', 'สามารถเดินทางต่างจังหวัดได้'],
                benefits: ['ค่าคอมมิชชั่นสูง', 'ค่าเดินทาง', 'ประกันชีวิต', 'รถยนต์บริษัท'],
                postedDate: '2025-05-15'
            },
            {
                id: '5',
                title: 'HR Generalist',
                company: 'People First Corporation',
                location: 'ปทุมธานี',
                type: 'full-time',
                category: 'HR',
                salary: '28,000 - 40,000',
                description: 'รับสมัครผู้เชี่ยวชาญด้านทรัพยากรบุคคลที่มีประสบการณ์ครบวงจร',
                requirements: ['ปริญญาตรี สาขาทรัพยากรบุคคล หรือสาขาที่เกี่ยวข้อง', 'ประสบการณ์ 2-3 ปี ในงาน HR', 'มีความรู้กฎหมายแรงงาน', 'มีทักษะการสื่อสารและการแก้ไขปัญหา'],
                benefits: ['การพัฒนาบุคลากร', 'ประกันสุขภาพครอบครัว', 'วันหยุดพิเศษ', 'ส่วนลดสินค้าบริษัท'],
                postedDate: '2025-05-19'
            }
        ];
        
        localStorage.setItem('jobs', JSON.stringify(sampleJobs));
    }
}

// Apply for a job
function applyForJob(jobId) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    
    if (!currentUser.id) {
        alert('กรุณาเข้าสู่ระบบก่อน');
        return;
    }
    
    if (!currentUser.resume) {
        alert('กรุณาอัปโหลด Resume ก่อนสมัครงาน');
        window.location.href = 'profile.html';
        return;
    }
    
    const jobs = JSON.parse(localStorage.getItem('jobs') || '[]');
    const job = jobs.find(j => j.id === jobId);
    
    // Check if already applied
    const applications = JSON.parse(localStorage.getItem('jobApplications') || '[]');
    const existingApplication = applications.find(app => 
        app.userId === currentUser.id && app.jobId === jobId
    );
    
    if (existingApplication) {
        alert('คุณได้สมัครงานนี้แล้ว');
        return;
    }
    
    // Create new application
    const application = {
        id: Date.now().toString(),
        userId: currentUser.id,
        jobId: jobId,
        jobTitle: job.title,
        companyName: job.company,
        appliedDate: new Date().toISOString(),
        status: 'pending',
        resume: currentUser.resume
    };
    
    applications.push(application);
    localStorage.setItem('jobApplications', JSON.stringify(applications));
    
    alert('สมัครงานสำเร็จ! คุณสามารถตรวจสอบสถานะได้ที่หน้าโปรไฟล์');
    return true;
}

// Get job applications for current user
function getUserApplications() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
    if (!currentUser.id) return [];
    
    const applications = JSON.parse(localStorage.getItem('jobApplications') || '[]');
    return applications.filter(app => app.userId === currentUser.id);
}

// Format job type for display
function getJobTypeText(type) {
    const typeMap = {
        'full-time': 'งานประจำ',
        'part-time': 'พาร์ทไทม์',
        'contract': 'สัญญาจ้าง',
        'remote': 'ทำงานจากบ้าน'
    };
    return typeMap[type] || type;
}

// Format application status for display
function getStatusText(status) {
    const statusMap = {
        'pending': 'รอการพิจารณา',
        'reviewing': 'กำลังพิจารณา',
        'interviewed': 'ผ่านการสัมภาษณ์',
        'accepted': 'ได้รับการตอบรับ',
        'rejected': 'ไม่ผ่านการคัดเลือก'
    };
    return statusMap[status] || status;
}

// Fetch jobs from external platforms using job-integrations.js
async function fetchExternalJobs() {
    try {
        // Display loading message
        const jobListings = document.getElementById('job-listings');
        if (jobListings) {
            jobListings.innerHTML = '<div class="loading">กำลังโหลดข้อมูลตำแหน่งงานจากแพลตฟอร์มต่างๆ...</div>';
        }
        
        // Fetch jobs from all sources
        const externalJobs = await jobIntegrations.getAllJobs();
        
        // Get existing jobs from localStorage
        const existingJobs = JSON.parse(localStorage.getItem('jobs') || '[]');
        
        // Convert external jobs to match our format
        const formattedExternalJobs = externalJobs.map(job => {
            return {
                id: job.id,
                title: job.title,
                company: job.company,
                location: job.location,
                type: job.type,
                category: job.category || getCategoryFromTitle(job.title),
                salary: `${formatSalary(job.salaryMin)} - ${formatSalary(job.salaryMax)}`,
                description: job.description,
                requirements: job.requirements || ['ไม่ระบุ'],
                benefits: job.benefits || ['ไม่ระบุ'],
                postedDate: job.postedDate,
                source: job.source,
                sourceUrl: job.url
            };
        });
        
        // Combine with existing jobs, prioritizing external ones for duplicates
        const combinedJobs = mergeJobs(existingJobs, formattedExternalJobs);
        
        // Save combined jobs to localStorage
        localStorage.setItem('jobs', JSON.stringify(combinedJobs));
        
        // Display jobs if on jobs page
        if (window.location.pathname.includes('jobs.html')) {
            displayJobs(combinedJobs);
        }
    } catch (error) {
        console.error('Error fetching external jobs:', error);
        // If error, just display existing jobs
        const existingJobs = JSON.parse(localStorage.getItem('jobs') || '[]');
        if (window.location.pathname.includes('jobs.html')) {
            displayJobs(existingJobs);
        }
    }
}

// Merge jobs from different sources, avoiding duplicates
function mergeJobs(localJobs, externalJobs) {
    // Create map of existing jobs by title+company combo
    const jobMap = new Map();
    
    // Add local jobs to map
    localJobs.forEach(job => {
        const key = `${job.title.toLowerCase()}-${job.company.toLowerCase()}`;
        jobMap.set(key, job);
    });
    
    // Add or replace with external jobs
    externalJobs.forEach(job => {
        const key = `${job.title.toLowerCase()}-${job.company.toLowerCase()}`;
        jobMap.set(key, job);
    });
    
    // Convert map back to array
    return Array.from(jobMap.values());
}

// Format salary for display
function formatSalary(salary) {
    if (!salary) return '0';
    return salary.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Guess category from job title
function getCategoryFromTitle(title) {
    const titleLower = title.toLowerCase();
    
    if (titleLower.includes('developer') || titleLower.includes('engineer') || 
        titleLower.includes('programmer') || titleLower.includes('software') || 
        titleLower.includes('tech') || titleLower.includes('it')) {
        return 'IT';
    }
    
    if (titleLower.includes('marketing') || titleLower.includes('seo') || 
        titleLower.includes('content') || titleLower.includes('brand')) {
        return 'Marketing';
    }
    
    if (titleLower.includes('sales') || titleLower.includes('account executive')) {
        return 'Sales';
    }
    
    if (titleLower.includes('hr') || titleLower.includes('human resource')) {
        return 'HR';
    }
    
    if (titleLower.includes('finance') || titleLower.includes('accountant') || 
        titleLower.includes('financial')) {
        return 'Finance';
    }
    
    return 'Other';
}