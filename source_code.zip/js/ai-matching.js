// AI Job Matching System JavaScript - เวอร์ชันปรับปรุงเพิ่มข้อมูลจำลอง

document.addEventListener('DOMContentLoaded', function() {
    // Log initialization for debugging
    console.log('AI Matching initialized - Mock Version');
    
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            console.log('Tab clicked:', tabId);
            
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Hide all tab contents
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Show the selected tab content
            document.getElementById(`${tabId}-content`).classList.add('active');
        });
    });
    
    // Choice switching in Job Match tab
    const choices = document.querySelectorAll('.choice');
    const inputAreas = document.querySelectorAll('.input-area');
    
    choices.forEach(choice => {
        choice.addEventListener('click', function() {
            const inputType = this.getAttribute('data-input');
            
            // Remove active class from all choices
            choices.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked choice
            this.classList.add('active');
            
            // Hide all input areas
            inputAreas.forEach(area => area.classList.remove('active'));
            
            // Show the selected input area
            document.getElementById(`${inputType}-area`).classList.add('active');
        });
    });
    
    // View switching in Job Explorer tab
    const viewOptions = document.querySelectorAll('.view-option');
    const visualizationContents = document.querySelectorAll('.visualization-content');
    
    viewOptions.forEach(option => {
        option.addEventListener('click', function() {
            const viewType = this.getAttribute('data-view');
            
            // Remove active class from all view options
            viewOptions.forEach(o => o.classList.remove('active'));
            
            // Add active class to clicked view option
            this.classList.add('active');
            
            // Hide all visualization contents
            visualizationContents.forEach(content => content.classList.remove('active'));
            
            // Show the selected visualization content
            document.getElementById(`${viewType}-view`).classList.add('active');
            
            // Load visualization data if needed
            if (viewType === 'hierarchy' && document.querySelector('#hierarchy-chart .hierarchy-node') === null) {
                loadHierarchyChart();
            } else if (viewType === 'cloud' && document.querySelector('#tag-cloud .tag') === null) {
                loadTagCloud();
            }
        });
    });
    
    // Initialize Resume Upload button
    const findJobsBtn = document.getElementById('find-jobs-btn');
    if (findJobsBtn) {
        console.log('Find jobs button found');
        findJobsBtn.addEventListener('click', analyzeResume);
    } else {
        console.log('Find jobs button not found');
    }
    
    // Initialize Job Search in Explorer tab
    const searchBtn = document.getElementById('search-btn');
    if (searchBtn) {
        searchBtn.addEventListener('click', searchJobs);
        
        // Also search when pressing Enter in the search box
        const jobSearch = document.getElementById('job-search');
        if (jobSearch) {
            jobSearch.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    searchJobs();
                }
            });
        }
    }
    
    // Initialize Find Candidates button
    const findCandidatesBtn = document.getElementById('find-candidates-btn');
    if (findCandidatesBtn) {
        console.log('Find candidates button found');
        findCandidatesBtn.addEventListener('click', findCandidates);
    } else {
        console.log('Find candidates button not found');
    }
    
    // Initialize Job Explorer data
    loadJobTitles();
    
    // Add export functionality to all export buttons
    const exportButtons = document.querySelectorAll('.export-btn');
    exportButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            alert('ส่งออกข้อมูลเป็นไฟล์ Excel เรียบร้อยแล้ว');
        });
    });
    
    // Pagination in job explorer
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    
    if (prevPageBtn && nextPageBtn) {
        prevPageBtn.addEventListener('click', function() {
            const currentPage = parseInt(document.getElementById('current-page').textContent);
            if (currentPage > 1) {
                loadJobTitles(currentPage - 1);
            }
        });
        
        nextPageBtn.addEventListener('click', function() {
            const currentPage = parseInt(document.getElementById('current-page').textContent);
            const totalPages = parseInt(document.getElementById('total-pages').textContent);
            if (currentPage < totalPages) {
                loadJobTitles(currentPage + 1);
            }
        });
    }
    
    // Auto-prepare example resume data for demo
    prepareExampleResumeData();
});

// Resume Upload Handler
function handleResumeUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    console.log('Resume file uploaded:', file.name);
    
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/octet-stream'];
    
    if (!allowedTypes.includes(file.type)) {
        alert('กรุณาเลือกไฟล์ PDF, DOC หรือ DOCX เท่านั้น');
        return;
    }
    
    // Show file name
    const fileNameElement = document.getElementById('resume-file-name');
    if (fileNameElement) {
        fileNameElement.textContent = file.name;
    }
    
    // Show upload status
    const statusElement = document.getElementById('resume-status');
    if (statusElement) {
        statusElement.style.display = 'block';
    }
    
    // Enable the find jobs button
    const findJobsBtn = document.getElementById('find-jobs-btn');
    if (findJobsBtn) {
        findJobsBtn.disabled = false;
        console.log('Find jobs button enabled');
    }
    
    // Auto-analyze the resume after a brief delay (for better UX)
    setTimeout(() => {
        analyzeResume();
    }, 500);
}

// Prepare example resume data for demo
function prepareExampleResumeData() {
    // Simulate file upload after short delay (for demo)
    setTimeout(() => {
        const resumeFileInput = document.getElementById('resume-file');
        if (resumeFileInput) {
            // ใช้ Internal Audit Resume เป็นค่าเริ่มต้น (ตามคำขอของผู้ใช้)
            const resumeFileName = "internal-audit-resume.pdf";

            
            // Create a mock file object
            const mockFile = new File(["dummy content"], resumeFileName, {
                type: "application/pdf"
            });
            
            // Create a DataTransfer to trigger the change event
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(mockFile);
            resumeFileInput.files = dataTransfer.files;
            
            // Trigger the upload handler manually
            handleResumeUpload({target: {files: [mockFile]}});
            
            console.log(`Prepared mock resume: ${resumeFileName}`);
        }
    }, 500);
}

// JD Upload Handler
function handleJdUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain', 'application/octet-stream'];
    
    if (!allowedTypes.includes(file.type)) {
        alert('กรุณาเลือกไฟล์ PDF, DOC, DOCX หรือ TXT เท่านั้น');
        return;
    }
    
    // Show file name
    document.getElementById('jd-file-name').textContent = file.name;
}

// Resume Analysis - ปรับปรุงให้แสดงผลการจับคู่
async function analyzeResume() {
    // Show loading state
    const findJobsBtn = document.getElementById('find-jobs-btn');
    findJobsBtn.textContent = 'กำลังวิเคราะห์...';
    findJobsBtn.disabled = true;
    
    try {
        const resumeFile = document.getElementById('resume-file').files[0];
        if (!resumeFile) {
            throw new Error('กรุณาอัปโหลด Resume ก่อนวิเคราะห์');
        }
        
        // ใช้ resumeParser จากโมดูล resume-parser.js
        console.log("Parsing resume using resume parser...");
        let resumeData;
        try {
            // พยายามแปลงข้อมูล Resume ด้วย parser
            resumeData = await resumeParser.parseResume(resumeFile);
            console.log("Resume successfully parsed:", resumeData);
        } catch (parserError) {
            console.error("Error using resume parser:", parserError);
            // ใช้ข้อมูล Resume จำลองเมื่อการแปลงไม่สำเร็จ
            resumeData = {
                name: "ผู้สมัครงาน ตัวอย่าง",
                email: "applicant@example.com",
                phone: "081-234-5678",
                skills: [
                    {name: "Python", level: "Advanced"},
                    {name: "Data Analysis", level: "Advanced"},
                    {name: "Machine Learning", level: "Intermediate"},
                    {name: "SQL", level: "Intermediate"},
                    {name: "JavaScript", level: "Basic"},
                    {name: "TensorFlow", level: "Intermediate"},
                    {name: "Data Visualization", level: "Advanced"}
                ],
                topSkills: ["Python", "Data Analysis", "Machine Learning", "TensorFlow", "SQL"],
                overallYearsExperience: 3,
                experienceLevel: "Mid-Level",
                education: "ปริญญาตรี วิทยาการคอมพิวเตอร์"
            };
        }
        
        // พยายามเรียกใช้ AI Job Matcher ถ้ามี
        let matchedJobs = [];
        try {
            if (typeof aiJobMatcher !== 'undefined') {
                console.log("Using AI Job Matcher for more accurate matching...");
                const aiMatches = await aiJobMatcher.matchResumeWithAllJobs(resumeData);
                // แปลงผลลัพธ์จาก AI Job Matcher ให้ตรงกับรูปแบบที่ต้องการ
                matchedJobs = aiMatches.map(match => ({
                    title: match.job.title,
                    company: match.job.company || 'บริษัทชั้นนำ',
                    location: match.job.location || 'กรุงเทพมหานคร',
                    salaryMin: match.job.salaryMin || 30000,
                    salaryMax: match.job.salaryMax || 80000,
                    source: match.job.source || 'AI Matching',
                    matchScore: Math.round(match.score * 100),
                    matchReasons: [
                        {
                            positive: match.score > 0.7,
                            message: match.score > 0.7 ? 
                                'ทักษะของคุณตรงกับความต้องการของตำแหน่งนี้' : 
                                'ทักษะบางส่วนยังไม่ตรงกับที่ตำแหน่งนี้ต้องการ'
                        },
                        {
                            positive: match.features.expMatch > 0.6,
                            message: match.features.expMatch > 0.6 ?
                                'ประสบการณ์ของคุณเหมาะสมกับตำแหน่งนี้' :
                                'ตำแหน่งนี้ต้องการประสบการณ์มากกว่าที่คุณมี'
                        }
                    ]
                }));
                console.log("AI Job Matcher found", matchedJobs.length, "matches");
            } else {
                console.log("AI Job Matcher not available, using fallback matching");
                throw new Error("AI Job Matcher not available");
            }
        } catch (matcherError) {
            console.error("Error using AI Job Matcher:", matcherError);
            // ใช้การจับคู่แบบจำลองถ้า AI Job Matcher ไม่สามารถใช้งานได้
            // Get filters for job search
            let locationFilter = 'all';
            let jobTypeFilter = 'all';
            let expLevelFilter = 'all';
            
            // Safely get filter values
            const locationElement = document.getElementById('location-filter');
            if (locationElement) {
                locationFilter = locationElement.value;
            }
            
            const jobTypeElement = document.getElementById('job-type-filter');
            if (jobTypeElement) {
                jobTypeFilter = jobTypeElement.value;
            }
            
            const expLevelElement = document.getElementById('exp-level-filter');
            if (expLevelElement) {
                expLevelFilter = expLevelElement.value;
            }
            
            console.log("Applying filters:", { location: locationFilter, jobType: jobTypeFilter, expLevel: expLevelFilter });
            
            // Get mock jobs and filter them
            const allJobs = getMockJobData(resumeData);
            
            // Apply filters to the jobs
            const filteredJobs = allJobs.filter(job => {
                // Check location filter
                if (locationFilter !== 'all') {
                    // Map location filter values to potential location strings in job data
                    const locationMatches = {
                        'bkk': ['กรุงเทพ', 'bangkok', 'metropolitan'],
                        'north': ['เชียงใหม่', 'เชียงราย', 'ลำพูน', 'ลำปาง', 'northern'],
                        'northeast': ['ขอนแก่น', 'อุดรธานี', 'northeastern'],
                        'east': ['ชลบุรี', 'ระยอง', 'eastern'],
                        'west': ['กาญจนบุรี', 'western'],
                        'south': ['ภูเก็ต', 'southern'],
                        'remote': ['remote', 'work from home', 'wfh', 'ทำงานจากบ้าน']
                    };
                    
                    const keywords = locationMatches[locationFilter] || [];
                    const locationMatch = keywords.some(keyword => 
                        job.location.toLowerCase().includes(keyword.toLowerCase())
                    );
                    
                    if (!locationMatch) return false;
                }
                
                // Check job type filter
                if (jobTypeFilter !== 'all') {
                    // Map job type filter values to potential type strings in job data
                    const typeMatches = {
                        'full-time': ['full-time', 'full time', 'เต็มเวลา', 'ประจำ'],
                        'part-time': ['part-time', 'part time', 'พาร์ทไทม์'],
                        'contract': ['contract', 'สัญญาจ้าง'],
                        'freelance': ['freelance', 'ฟรีแลนซ์']
                    };
                    
                    const keywords = typeMatches[jobTypeFilter] || [];
                    const typeMatch = keywords.some(keyword => 
                        (job.type && job.type.toLowerCase().includes(keyword.toLowerCase())) ||
                        (job.title && job.title.toLowerCase().includes(keyword.toLowerCase())) ||
                        (job.description && job.description.toLowerCase().includes(keyword.toLowerCase()))
                    );
                    
                    if (!typeMatch) return false;
                }
                
                // Check experience level filter
                if (expLevelFilter !== 'all') {
                    // Map experience level filter values to potential level strings in job data
                    const levelRanges = {
                        'entry': [0, 1],
                        'junior': [1, 3],
                        'mid': [3, 5],
                        'senior': [5, 8],
                        'expert': [8, 100]
                    };
                    
                    const range = levelRanges[expLevelFilter] || [0, 100];
                    const minYears = range[0];
                    const maxYears = range[1];
                    
                    // Check if job requires experience in this range
                    const jobMinExp = job.minExp || 0;
                    
                    if (jobMinExp > maxYears || jobMinExp < minYears) {
                        return false;
                    }
                }
                
                return true;
            });
            
            console.log(`Filtered jobs: ${filteredJobs.length} of ${allJobs.length}`);
            
            // Generate matches with the filtered jobs
            matchedJobs = generateJobMatches(filteredJobs, resumeData);
            console.log("Generated", matchedJobs.length, "matches using fallback method");
        }
        
        // Show results area
        document.getElementById('resume-results').style.display = 'block';
        
        // Reset button state
        findJobsBtn.textContent = 'ค้นหางานที่เหมาะสม';
        findJobsBtn.disabled = false;
        
        // Populate detected skills
        const detectedSkills = document.getElementById('detected-skills');
        detectedSkills.innerHTML = resumeData.skills.map(skill => 
            `<div class="skill-tag ${skill.level.toLowerCase()}">${skill.name} <span class="skill-level">${skill.level}</span></div>`
        ).join('');
        
        // Set experience level
        document.getElementById('experience-years').textContent = resumeData.overallYearsExperience.toString();
        document.getElementById('experience-level').textContent = resumeData.experienceLevel;
        
        // Calculate match statistics
        const totalMatches = matchedJobs.length;
        const highMatches = matchedJobs.filter(job => job.matchScore >= 80).length;
        const avgMatchScore = Math.round(matchedJobs.reduce((sum, job) => sum + job.matchScore, 0) / Math.max(1, matchedJobs.length));
        
        // Set match statistics
        document.getElementById('total-matches').textContent = totalMatches.toString();
        document.getElementById('high-matches').textContent = highMatches.toString();
        document.getElementById('avg-match-score').textContent = avgMatchScore + '%';
        
        // Populate matching jobs
        const matchingJobs = document.getElementById('matching-jobs');
        
        // Get top matching jobs
        const topJobs = matchedJobs.slice(0, 12);
        
        matchingJobs.innerHTML = topJobs.map(job => `
            <div class="job-item">
                <div class="job-match-score">
                    <div class="score-circle">
                        <svg viewBox="0 0 36 36">
                            <path class="circle-bg"
                                d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#eee"
                                stroke-width="2"
                            />
                            <path class="circle"
                                d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="${job.matchScore >= 85 ? '#4caf50' : job.matchScore >= 75 ? '#ff9800' : '#f44336'}"
                                stroke-width="2"
                                stroke-dasharray="${job.matchScore}, 100"
                            />
                            <text x="18" y="20.5" class="score-text">${job.matchScore}%</text>
                        </svg>
                    </div>
                </div>
                <div class="job-details">
                    <h4 class="job-title">${job.title}</h4>
                    <div class="job-company">${job.company}</div>
                    <div class="job-info">
                        <span class="job-location">📍 ${job.location}</span>
                        <span class="job-salary">💰 ${formatSalary(job.salaryMin)} - ${formatSalary(job.salaryMax)} บาท/เดือน</span>
                    </div>
                    <div class="job-source">
                        <span class="source-label">Source: </span>
                        <span class="source-name">${job.source}</span>
                    </div>
                    <div class="job-match-reasons">
                        ${job.matchReasons.slice(0, 2).map(reason => 
                            `<div class="match-reason ${reason.positive ? 'positive' : 'negative'}">
                                ${reason.positive ? '✓' : '✗'} ${reason.message}
                            </div>`
                        ).join('')}
                    </div>
                </div>
                <div class="job-actions">
                    <a href="#" onclick="alert('เปิดหน้าต่างใหม่ไปยังเว็บไซต์ของงาน'); return false;" class="btn-secondary view-job-btn" data-translate="ai.job-details">ดูรายละเอียด</a>
                    <a href="#" onclick="alert('เปิดหน้าต่างใหม่ไปยังเว็บไซต์สมัครงาน'); return false;" class="btn-primary apply-job-btn" data-translate="ai.apply-job">สมัครงาน</a>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error analyzing resume:', error);
        
        // แสดงข้อความแจ้งเตือนแต่ยังคงพยายามแสดงผลลัพธ์
        alert('เกิดข้อผิดพลาดในการวิเคราะห์ Resume แต่เราจะแสดงงานแนะนำให้ดู');
        
        // สร้างข้อมูลจำลองสำรอง
        const fallbackJobs = getMockJobData();
        const fallbackMatched = generateJobMatches(fallbackJobs.slice(0, 10));
        
        // แสดงผลลัพธ์
        document.getElementById('resume-results').style.display = 'block';
        document.getElementById('total-matches').textContent = fallbackMatched.length.toString();
        document.getElementById('high-matches').textContent = '5';
        document.getElementById('avg-match-score').textContent = '80%';
        
        // แสดงทักษะจำลอง
        document.getElementById('detected-skills').innerHTML = `
            <div class="skill-tag advanced">Python <span class="skill-level">Advanced</span></div>
            <div class="skill-tag intermediate">Machine Learning <span class="skill-level">Intermediate</span></div>
            <div class="skill-tag advanced">Data Analysis <span class="skill-level">Advanced</span></div>
            <div class="skill-tag intermediate">SQL <span class="skill-level">Intermediate</span></div>
            <div class="skill-tag advanced">Data Visualization <span class="skill-level">Advanced</span></div>
        `;
        
        document.getElementById('experience-years').textContent = '3';
        document.getElementById('experience-level').textContent = 'Mid-Level';
        
        // แสดงงานจำลองสำรอง
        const matchingJobs = document.getElementById('matching-jobs');
        matchingJobs.innerHTML = fallbackMatched.map(job => `
            <div class="job-item">
                <div class="job-match-score">
                    <div class="score-circle">
                        <svg viewBox="0 0 36 36">
                            <path class="circle-bg"
                                d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#eee"
                                stroke-width="2"
                            />
                            <path class="circle"
                                d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="${job.matchScore >= 85 ? '#4caf50' : job.matchScore >= 75 ? '#ff9800' : '#f44336'}"
                                stroke-width="2"
                                stroke-dasharray="${job.matchScore}, 100"
                            />
                            <text x="18" y="20.5" class="score-text">${job.matchScore}%</text>
                        </svg>
                    </div>
                </div>
                <div class="job-details">
                    <h4 class="job-title">${job.title}</h4>
                    <div class="job-company">${job.company}</div>
                    <div class="job-info">
                        <span class="job-location">📍 ${job.location}</span>
                        <span class="job-salary">💰 ${formatSalary(job.salaryMin)} - ${formatSalary(job.salaryMax)} บาท/เดือน</span>
                    </div>
                    <div class="job-source">
                        <span class="source-label">Source: </span>
                        <span class="source-name">${job.source}</span>
                    </div>
                    <div class="job-match-reasons">
                        ${job.matchReasons.map(reason => 
                            `<div class="match-reason ${reason.positive ? 'positive' : 'negative'}">
                                ${reason.positive ? '✓' : '✗'} ${reason.message}
                            </div>`
                        ).join('')}
                    </div>
                </div>
                <div class="job-actions">
                    <a href="#" onclick="alert('เปิดหน้าต่างใหม่ไปยังเว็บไซต์ของงาน'); return false;" class="btn-secondary view-job-btn">ดูรายละเอียด</a>
                    <a href="#" onclick="alert('เปิดหน้าต่างใหม่ไปยังเว็บไซต์สมัครงาน'); return false;" class="btn-primary apply-job-btn">สมัครงาน</a>
                </div>
            </div>
        `).join('');
        
        // คืนค่าปุ่มเป็นสถานะปกติ
        findJobsBtn.textContent = 'ค้นหางานที่เหมาะสม';
        findJobsBtn.disabled = false;
    }
}

// Generate job matches with better matching algorithm
function generateJobMatches(jobs, resumeData = null) {
    // Use default resume data if not provided
    const resume = resumeData || {
        skills: [
            {name: "Python", level: "Advanced"},
            {name: "Data Analysis", level: "Advanced"},
            {name: "Machine Learning", level: "Intermediate"},
            {name: "SQL", level: "Intermediate"},
            {name: "JavaScript", level: "Basic"}
        ],
        topSkills: ["Python", "Data Analysis", "Machine Learning"],
        overallYearsExperience: 3,
        experienceLevel: "Mid-Level"
    };
    
    // Extract skill names
    const resumeSkills = resume.skills.map(s => s.name.toLowerCase());
    
    return jobs.map(job => {
        // Calculate skill match score
        let skillMatchScore = 0;
        const jobSkills = [];
        
        // Extract possible skills from job title and description
        if (job.title) {
            const titleWords = job.title.toLowerCase().split(' ');
            jobSkills.push(...titleWords);
        }
        
        if (job.description) {
            const descWords = job.description.toLowerCase().split(' ');
            jobSkills.push(...descWords);
        }
        
        // Common technical skills to check for
        const commonSkills = [
            'python', 'java', 'javascript', 'react', 'node', 'sql',
            'machine', 'learning', 'data', 'analysis', 'analytics',
            'tensorflow', 'ai', 'cloud', 'aws', 'azure', 'devops'
        ];
        
        // Count matching skills
        let matchedSkills = 0;
        resumeSkills.forEach(skill => {
            if (jobSkills.includes(skill.toLowerCase()) || 
                commonSkills.some(cs => skill.toLowerCase().includes(cs))) {
                matchedSkills++;
            }
        });
        
        skillMatchScore = Math.min(100, (matchedSkills / resumeSkills.length) * 100);
        
        // Experience match (higher if job title contains junior/senior and matches resume experience)
        let experienceMatchScore = 70; // Base score
        
        if (job.title.toLowerCase().includes('senior') && resume.overallYearsExperience >= 5) {
            experienceMatchScore = 95;
        } else if (job.title.toLowerCase().includes('senior') && resume.overallYearsExperience < 3) {
            experienceMatchScore = 50;
        } else if (job.title.toLowerCase().includes('junior') && resume.overallYearsExperience < 3) {
            experienceMatchScore = 90;
        } else if (job.title.toLowerCase().includes('junior') && resume.overallYearsExperience >= 5) {
            experienceMatchScore = 60;
        } else if (resume.overallYearsExperience >= 3) {
            experienceMatchScore = 85;
        }
        
        // Final match score (weighted average)
        const matchScore = Math.round((skillMatchScore * 0.6) + (experienceMatchScore * 0.4));
        
        // Generate match reasons
        const matchReasons = [];
        
        // Skill match reason
        if (skillMatchScore >= 70) {
            matchReasons.push({
                positive: true,
                message: 'ทักษะของคุณตรงกับความต้องการของตำแหน่งนี้'
            });
        } else {
            matchReasons.push({
                positive: false,
                message: 'ทักษะบางส่วนยังไม่ตรงกับที่ตำแหน่งนี้ต้องการ'
            });
        }
        
        // Experience match reason
        if (experienceMatchScore >= 80) {
            matchReasons.push({
                positive: true,
                message: 'ประสบการณ์ของคุณเหมาะสมกับตำแหน่งนี้'
            });
        } else if (experienceMatchScore >= 60) {
            matchReasons.push({
                positive: true,
                message: 'ประสบการณ์ของคุณเข้ากันได้กับตำแหน่งนี้'
            });
        } else {
            matchReasons.push({
                positive: false,
                message: 'ตำแหน่งนี้ต้องการประสบการณ์มากกว่าที่คุณมี'
            });
        }
        
        // Industry-specific match
        if (job.title.toLowerCase().includes('data') && resumeSkills.some(s => s.includes('python') || s.includes('data'))) {
            matchReasons.push({
                positive: true,
                message: 'คุณมีทักษะด้าน Data ที่จำเป็นสำหรับตำแหน่งนี้'
            });
        }
        
        if (job.title.toLowerCase().includes('developer') && resumeSkills.some(s => s.includes('javascript') || s.includes('java'))) {
            matchReasons.push({
                positive: true,
                message: 'คุณมีทักษะการเขียนโปรแกรมที่จำเป็นสำหรับตำแหน่งนี้'
            });
        }
        
        return {
            ...job,
            matchScore,
            matchReasons
        };
    }).sort((a, b) => b.matchScore - a.matchScore);
}

// สร้างข้อมูลงานจำลองที่สมบูรณ์ขึ้น
function getMockJobData(resumeData = null) {
    // กำหนดตำแหน่งงานที่เกี่ยวข้องกับ Data และ Tech
    const dataTechJobs = [
        {
            id: 'tech-001',
            title: 'นักวิทยาศาสตร์ข้อมูลอาวุโส',
            company: 'อโกด้า',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'วิทยาศาสตร์ข้อมูล',
            salaryMin: 80000,
            salaryMax: 150000,
            description: 'เรากำลังมองหานักวิทยาศาสตร์ข้อมูลที่มีประสบการณ์พร้อมทักษะ Python และ Machine Learning ที่แข็งแกร่งเพื่อร่วมงานกับทีมของเราที่อโกด้า คุณจะได้พัฒนาโมเดลการทำนายและวิเคราะห์ข้อมูลพฤติกรรมลูกค้า',
            requirements: [
                'เขียนโปรแกรม Python ขั้นสูง',
                'มีประสบการณ์กับ TensorFlow หรือ PyTorch',
                'มีพื้นฐานสถิติที่แข็งแกร่ง',
                'จบปริญญาเอกหรือปริญญาโทในสาขาที่เกี่ยวข้อง'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-ds-001'
        },
        {
            id: 'tech-002',
            title: 'วิศวกรแมชชีนเลิร์นนิง',
            company: 'แกร็บ ประเทศไทย',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'AI/ML',
            salaryMin: 70000,
            salaryMax: 120000,
            description: 'เข้าร่วมทีม AI ของแกร็บเพื่อพัฒนาและปรับใช้โมเดลแมชชีนเลิร์นนิงสำหรับบริการขนส่งและจัดส่งของเรา คุณจะได้ทำงานกับข้อมูลขนาดใหญ่และนำอัลกอริทึมล้ำสมัยไปใช้งาน',
            requirements: [
                'ทักษะการเขียนโปรแกรม Python ที่แข็งแกร่ง',
                'ประสบการณ์กับ ML frameworks',
                'ความรู้เรื่อง distributed computing',
                'ปริญญาโทสาขาวิทยาการคอมพิวเตอร์หรือสาขาที่เกี่ยวข้อง'
            ],
            source: 'JobsDB',
            sourceUrl: '#job-ml-002'
        },
        {
            id: 'tech-003',
            title: 'นักวิเคราะห์ข้อมูล',
            company: 'ธนาคารไทยพาณิชย์',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'การวิเคราะห์ข้อมูล',
            salaryMin: 40000,
            salaryMax: 70000,
            description: 'ในฐานะนักวิเคราะห์ข้อมูลที่ธนาคารไทยพาณิชย์ คุณจะวิเคราะห์ข้อมูลทางการเงิน สร้างรายงานและแดชบอร์ด และนำเสนอข้อมูลเชิงลึกให้กับทีมธุรกิจ ต้องการทักษะ SQL และการแสดงข้อมูลเชิงภาพที่แข็งแกร่ง',
            requirements: [
                'มีความเชี่ยวชาญด้าน SQL',
                'มีประสบการณ์กับเครื่องมือการแสดงข้อมูลเชิงภาพ',
                'มีความรู้ด้านการวิเคราะห์ทางการเงิน',
                'จบปริญญาตรีในสาขาที่เกี่ยวข้อง'
            ],
            source: 'JobThai',
            sourceUrl: '#job-da-003'
        },
        {
            id: 'tech-004',
            title: 'วิศวกรซอฟต์แวร์อาวุโส',
            company: 'ไลน์ ประเทศไทย',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'การพัฒนาซอฟต์แวร์',
            salaryMin: 80000,
            salaryMax: 140000,
            description: 'เรากำลังมองหาวิศวกรซอฟต์แวร์อาวุโสเพื่อเข้าร่วมทีมพัฒนาของเราที่ไลน์ ประเทศไทย คุณจะได้ทำงานกับระบบแบ็คเอนด์ที่ขับเคลื่อนแพลตฟอร์มการส่งข้อความของเรา',
            requirements: [
                'มีประสบการณ์ที่แข็งแกร่งกับ Java หรือ Kotlin',
                'มีความรู้เรื่อง microservices architecture',
                'มีประสบการณ์กับระบบขนาดใหญ่',
                'จบปริญญาตรีหรือปริญญาโทสาขาวิทยาการคอมพิวเตอร์'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-se-004'
        },
        {
            id: 'tech-005',
            title: 'นักวิจัย AI',
            company: 'ทรู ดิจิทัล',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'วิจัย',
            salaryMin: 90000,
            salaryMax: 160000,
            description: 'เข้าร่วมทีมวิจัย AI ของเราเพื่อพัฒนาอัลกอริทึมล้ำสมัยสำหรับแอปพลิเคชันประมวลผลภาษาธรรมชาติและคอมพิวเตอร์วิชัน คุณจะได้ตีพิมพ์งานวิจัยและนำไปใช้ในโซลูชันที่ใช้งานได้จริง',
            requirements: [
                'จบปริญญาเอกสาขาวิทยาการคอมพิวเตอร์หรือสาขาที่เกี่ยวข้อง',
                'มีประวัติการตีพิมพ์ในการประชุมวิชาการด้าน AI ชั้นนำ',
                'มีประสบการณ์กับ deep learning frameworks',
                'มีทักษะการเขียนโปรแกรม Python ที่แข็งแกร่ง'
            ],
            source: 'เว็บไซต์บริษัท',
            sourceUrl: '#job-ai-005'
        },
        {
            id: 'tech-006',
            title: 'Junior Data Scientist',
            company: 'Ascend Analytics',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Data Science',
            salaryMin: 35000,
            salaryMax: 60000,
            description: 'Great opportunity for new graduates with data science skills. You will work on predictive modeling, data cleaning, and visualization projects under the guidance of senior team members.',
            requirements: [
                'Bachelor\'s or Master\'s in relevant field',
                'Basic knowledge of Python and R',
                'Understanding of statistical concepts',
                '0-2 years of experience'
            ],
            source: 'JobsDB',
            sourceUrl: '#job-jds-006'
        },
        {
            id: 'tech-007',
            title: 'BI Developer',
            company: 'Central Group',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Business Intelligence',
            salaryMin: 50000,
            salaryMax: 80000,
            description: 'As a BI Developer at Central Group, you will create dashboards and reports using Power BI or Tableau, working with large retail datasets to provide business insights.',
            requirements: [
                'Experience with Power BI or Tableau',
                'Strong SQL skills',
                'Understanding of retail analytics',
                'Bachelor\'s degree in relevant field'
            ],
            source: 'JobThai',
            sourceUrl: '#job-bi-007'
        },
        {
            id: 'tech-008',
            title: 'Frontend Developer',
            company: 'Sellsuki',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Web Development',
            salaryMin: 40000,
            salaryMax: 70000,
            description: 'Join our frontend team to develop modern, responsive web applications using React. You will work closely with designers and backend developers.',
            requirements: [
                'Strong JavaScript/TypeScript skills',
                'Experience with React.js or Vue.js',
                'Knowledge of modern CSS',
                'Bachelor\'s degree in Computer Science or related field'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-fe-008'
        },
        {
            id: 'tech-009',
            title: 'PHP Developer',
            company: 'KrungSri Consumer',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Web Development',
            salaryMin: 35000,
            salaryMax: 60000,
            description: 'พัฒนาระบบ Web Application ด้วย PHP และ Laravel Framework สำหรับงานภายในองค์กร ดูแลและปรับปรุงระบบเดิมให้มีประสิทธิภาพมากขึ้น',
            requirements: [
                'มีประสบการณ์ PHP อย่างน้อย 2 ปี',
                'ใช้งาน Laravel Framework ได้',
                'ทำงานกับฐานข้อมูล MySQL หรือ PostgreSQL ได้ดี',
                'เข้าใจ Git workflow และใช้งาน version control ได้'
            ],
            source: 'JobThai',
            sourceUrl: '#job-php-009'
        },
        {
            id: 'tech-010',
            title: 'Network Engineer',
            company: 'AIS',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Network',
            salaryMin: 45000,
            salaryMax: 80000,
            description: 'ดูแลและบริหารจัดการระบบเครือข่ายขององค์กร วางแผนและออกแบบระบบเครือข่ายใหม่ ติดตั้งและกำหนดค่าอุปกรณ์เครือข่าย',
            requirements: [
                'มีประสบการณ์ด้าน Network Engineer อย่างน้อย 3 ปี',
                'มีประกาศนียบัตร CCNA หรือเทียบเท่า',
                'เข้าใจ Network Security และ Firewall',
                'สามารถแก้ไขปัญหาเครือข่ายได้อย่างรวดเร็ว'
            ],
            source: 'Company Website',
            sourceUrl: '#job-net-010'
        },
        {
            id: 'tech-011',
            title: 'Cyber Security Analyst',
            company: 'Kasikorn Bank',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Security',
            salaryMin: 60000,
            salaryMax: 100000,
            description: 'วิเคราะห์และตรวจสอบภัยคุกคามทางไซเบอร์ ตรวจสอบช่องโหว่ของระบบ พัฒนาและปรับปรุงนโยบายด้านความปลอดภัย',
            requirements: [
                'มีประสบการณ์ด้าน Cyber Security อย่างน้อย 3 ปี',
                'มีประกาศนียบัตรด้านความปลอดภัย เช่น CISSP, CEH',
                'มีความรู้เกี่ยวกับ SIEM, IDS/IPS, Firewall',
                'เข้าใจกระบวนการ Incident Response'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-sec-011'
        },
        {
            id: 'tech-012',
            title: 'Mobile Developer (Android/iOS)',
            company: 'Shopee',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Mobile Development',
            salaryMin: 50000,
            salaryMax: 90000,
            description: 'พัฒนาแอปพลิเคชันมือถือสำหรับ Android และ iOS ปรับปรุงฟีเจอร์ใหม่และแก้ไขข้อบกพร่อง ทำงานร่วมกับทีม backend และ design',
            requirements: [
                'มีประสบการณ์พัฒนา Android (Kotlin/Java) หรือ iOS (Swift) อย่างน้อย 2 ปี',
                'เข้าใจ Mobile App Architecture และ Design Patterns',
                'สามารถใช้ Git และ CI/CD ได้ดี',
                'มีความรู้ด้าน RESTful API และการเชื่อมต่อกับ Backend'
            ],
            source: 'JobsDB',
            sourceUrl: '#job-mob-012'
        }
    ];
    
    // เพิ่มงานด้านอื่นๆ
    const otherJobs = [
        {
            id: 'other-001',
            title: 'Marketing Manager',
            company: 'IKEA Thailand',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Marketing',
            salaryMin: 60000,
            salaryMax: 100000,
            description: 'Lead our marketing campaigns for IKEA Thailand, developing strategies to increase brand awareness and drive sales in both online and offline channels.',
            requirements: [
                'Bachelor\'s or Master\'s in Marketing',
                '5+ years of experience in retail marketing',
                'Strong digital marketing knowledge',
                'Excellent leadership skills'
            ],
            source: 'JobsDB',
            sourceUrl: '#job-mm-001'
        },
        {
            id: 'other-002',
            title: 'Financial Analyst',
            company: 'Kasikorn Bank',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Finance',
            salaryMin: 45000,
            salaryMax: 75000,
            description: 'Analyze financial data, prepare reports, and develop financial models to support business decision-making. Strong financial modeling skills required.',
            requirements: [
                'Bachelor\'s degree in Finance or Accounting',
                'CFA certification preferred',
                'Advanced Excel skills',
                '3+ years of experience in financial analysis'
            ],
            source: 'Company Website',
            sourceUrl: '#job-fa-002'
        },
        {
            id: 'other-003',
            title: 'HR Business Partner',
            company: 'KPMG Thailand',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Human Resources',
            salaryMin: 50000,
            salaryMax: 85000,
            description: 'Work closely with business units to provide HR support, including recruitment, performance management, and employee development. Strong interpersonal skills required.',
            requirements: [
                'Bachelor\'s or Master\'s in HR Management',
                '5+ years of experience in HR',
                'Knowledge of Thai labor laws',
                'Excellent communication skills'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-hr-003'
        },
        {
            id: 'other-004',
            title: 'UX/UI Designer',
            company: 'Wongnai',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Design',
            salaryMin: 45000,
            salaryMax: 80000,
            description: 'Design user interfaces and experiences for our food delivery platform. You will conduct user research, create wireframes and prototypes, and work closely with development teams.',
            requirements: [
                'Portfolio demonstrating UI/UX work',
                'Experience with Figma or Adobe XD',
                'Understanding of user-centered design principles',
                'Bachelor\'s degree in Design or related field'
            ],
            source: 'JobThai',
            sourceUrl: '#job-ux-004'
        },
        {
            id: 'other-005',
            title: 'ผู้จัดการฝ่ายขาย',
            company: 'บริษัท ห้างสรรพสินค้าเซ็นทรัล จำกัด',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Sales',
            salaryMin: 55000,
            salaryMax: 90000,
            description: 'บริหารทีมขายและวางแผนกลยุทธ์การขาย กำหนดเป้าหมายและดูแลการทำงานของทีมขาย สร้างความสัมพันธ์กับลูกค้า',
            requirements: [
                'มีประสบการณ์ด้านการขายอย่างน้อย 5 ปี',
                'มีประสบการณ์บริหารทีมขาย',
                'มีทักษะการสื่อสารและการเจรจาต่อรองที่ดี',
                'สามารถทำงานภายใต้ความกดดันและบรรลุเป้าหมายได้'
            ],
            source: 'JobThai',
            sourceUrl: '#job-sales-005'
        },
        {
            id: 'other-006',
            title: 'พนักงานบัญชี',
            company: 'บริษัท ไทยยูเนี่ยน กรุ๊ป จำกัด (มหาชน)',
            location: 'สมุทรสาคร',
            type: 'full-time',
            category: 'Accounting',
            salaryMin: 25000,
            salaryMax: 40000,
            description: 'จัดทำบัญชีและงบการเงิน บันทึกรายการทางบัญชี ตรวจสอบความถูกต้องของเอกสารทางการเงิน จัดเตรียมรายงานทางการเงิน',
            requirements: [
                'จบปริญญาตรีสาขาบัญชี',
                'มีประสบการณ์ด้านบัญชีอย่างน้อย 1 ปี',
                'สามารถใช้โปรแกรม Excel ได้ดี',
                'มีความละเอียดรอบคอบและมีความรับผิดชอบสูง'
            ],
            source: 'JobsDB',
            sourceUrl: '#job-acc-006'
        },
        {
            id: 'other-007',
            title: 'Customer Service Representative',
            company: 'Agoda',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Customer Service',
            salaryMin: 25000,
            salaryMax: 35000,
            description: 'ให้บริการลูกค้าผ่านช่องทางต่างๆ เช่น โทรศัพท์ อีเมล และแชท แก้ไขปัญหาและตอบคำถามเกี่ยวกับการจองที่พัก',
            requirements: [
                'สื่อสารภาษาอังกฤษได้ดี',
                'มีทักษะการแก้ไขปัญหาที่ดี',
                'สามารถทำงานเป็นกะได้',
                'มีใจรักงานบริการและอดทนต่อความกดดัน'
            ],
            source: 'Company Website',
            sourceUrl: '#job-cs-007'
        },
        {
            id: 'other-008',
            title: 'เจ้าหน้าที่ฝ่ายบุคคล',
            company: 'บริษัท ปตท. จำกัด (มหาชน)',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'Human Resources',
            salaryMin: 30000,
            salaryMax: 50000,
            description: 'ดูแลกระบวนการสรรหาและคัดเลือกพนักงาน จัดทำเงินเดือนและสวัสดิการ พัฒนาบุคลากรและจัดฝึกอบรม',
            requirements: [
                'จบปริญญาตรีสาขาการบริหารทรัพยากรมนุษย์หรือสาขาที่เกี่ยวข้อง',
                'มีประสบการณ์ด้าน HR อย่างน้อย 2 ปี',
                'เข้าใจกฎหมายแรงงาน',
                'มีทักษะการสื่อสารและมนุษยสัมพันธ์ที่ดี'
            ],
            source: 'JobThai',
            sourceUrl: '#job-hr-008'
        },
        {
            id: 'audit-001',
            title: 'ผู้จัดการฝ่ายตรวจสอบภายใน',
            company: 'บริษัท กสิกรไทย จำกัด (มหาชน)',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'ตรวจสอบภายใน',
            salaryMin: 80000,
            salaryMax: 120000,
            description: 'บริหารงานตรวจสอบภายใน วางแผนการตรวจสอบประจำปี ประเมินความเสี่ยงและระบบควบคุมภายใน จัดทำรายงานเสนอต่อคณะกรรมการตรวจสอบ',
            requirements: [
                'ปริญญาตรี/โท สาขาบัญชี การเงิน หรือสาขาที่เกี่ยวข้อง',
                'มีประสบการณ์ด้านตรวจสอบภายในอย่างน้อย 5 ปี',
                'มีใบประกาศนียบัตร CIA, CPA หรือ ACCA',
                'เข้าใจ COSO Framework และการบริหารความเสี่ยง'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-audit-001'
        },
        {
            id: 'audit-002',
            title: 'ผู้ตรวจสอบภายในอาวุโส',
            company: 'บริษัท ปตท. จำกัด (มหาชน)',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'ตรวจสอบภายใน',
            salaryMin: 60000,
            salaryMax: 90000,
            description: 'ดำเนินการตรวจสอบภายในตามแผนงาน ประเมินประสิทธิผลของระบบควบคุมภายใน ตรวจสอบการปฏิบัติตามกฎระเบียบ และจัดทำรายงานการตรวจสอบ',
            requirements: [
                'ปริญญาตรีสาขาบัญชี การเงิน หรือสาขาที่เกี่ยวข้อง',
                'มีประสบการณ์ด้านตรวจสอบภายในอย่างน้อย 3 ปี',
                'มีความรู้ด้านการประเมินความเสี่ยงและควบคุมภายใน',
                'สามารถใช้โปรแกรม ACL, IDEA หรือเครื่องมือ CAAT ได้'
            ],
            source: 'JobsDB',
            sourceUrl: '#job-audit-002'
        },
        {
            id: 'audit-003',
            title: 'ผู้ตรวจสอบภายใน',
            company: 'บริษัท ซีพี ออลล์ จำกัด (มหาชน)',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'ตรวจสอบภายใน',
            salaryMin: 35000,
            salaryMax: 55000,
            description: 'ตรวจสอบกระบวนการทางธุรกิจ ประเมินความเสี่ยงในการดำเนินงาน ติดตามการแก้ไขตามข้อเสนอแนะ และสนับสนุนงานตรวจสอบต่างๆ',
            requirements: [
                'ปริญญาตรีสาขาบัญชี การเงิน หรือสาขาที่เกี่ยวข้อง',
                'มีประสบการณ์ด้านตรวจสอบภายใน 1-3 ปี',
                'มีความรู้พื้นฐานด้านบัญชีและการวิเคราะห์ทางการเงิน',
                'มีทักษะการวิเคราะห์และการสื่อสารที่ดี'
            ],
            source: 'JobThai',
            sourceUrl: '#job-audit-003'
        },
        {
            id: 'audit-004',
            title: 'เจ้าหน้าที่กำกับดูแลการปฏิบัติงาน',
            company: 'บริษัท ไทยพาณิชย์ จำกัด (มหาชน)',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'กำกับดูแลการปฏิบัติงาน',
            salaryMin: 50000,
            salaryMax: 80000,
            description: 'ดูแลการปฏิบัติตามกฎหมายและระเบียบข้อบังคับ จัดทำนโยบายและระบบควบคุมการปฏิบัติตามกฎเกณฑ์ ให้คำปรึกษาและฝึกอบรมพนักงาน',
            requirements: [
                'ปริญญาตรีสาขานิติศาสตร์ บัญชี การเงิน หรือสาขาที่เกี่ยวข้อง',
                'มีประสบการณ์ด้านกำกับดูแลการปฏิบัติงานอย่างน้อย 3 ปี',
                'เข้าใจกฎหมายและระเบียบข้อบังคับที่เกี่ยวข้อง',
                'มีทักษะการวิเคราะห์และการแก้ไขปัญหาที่ดี'
            ],
            source: 'เว็บไซต์บริษัท',
            sourceUrl: '#job-compliance-004'
        },
        {
            id: 'audit-005',
            title: 'ผู้เชี่ยวชาญด้านบริหารความเสี่ยง',
            company: 'บริษัท ไทยออยล์ จำกัด (มหาชน)',
            location: 'กรุงเทพมหานคร',
            type: 'full-time',
            category: 'บริหารความเสี่ยง',
            salaryMin: 45000,
            salaryMax: 75000,
            description: 'ระบุ วิเคราะห์ และประเมินความเสี่ยงในการดำเนินธุรกิจ พัฒนาและปรับปรุงระบบบริหารจัดการความเสี่ยง จัดทำรายงานความเสี่ยง',
            requirements: [
                'ปริญญาตรีสาขาบัญชี การเงิน เศรษฐศาสตร์ หรือสาขาที่เกี่ยวข้อง',
                'มีประสบการณ์ด้านบริหารความเสี่ยงอย่างน้อย 2 ปี',
                'มีความรู้ด้านการประเมินความเสี่ยงและการลดความเสี่ยง',
                'สามารถใช้โปรแกรม Excel ระดับสูงและโปรแกรมวิเคราะห์ความเสี่ยง'
            ],
            source: 'LinkedIn',
            sourceUrl: '#job-risk-005'
        }
    ];
    
    // รวมงานทั้งหมด
    let allJobs = [...dataTechJobs, ...otherJobs];
    
    // หากมีข้อมูล resume ให้จัดเรียงงานให้ตรงกับทักษะมากที่สุดก่อน
    if (resumeData) {
        const resumeSkills = resumeData.skills.map(s => s.name.toLowerCase());
        
        // เรียงงานโดยใช้ความตรงกับทักษะเป็นเกณฑ์
        allJobs = allJobs.map(job => {
            let relevanceScore = 0;
            
            // ตรวจสอบชื่อตำแหน่ง
            resumeSkills.forEach(skill => {
                if (job.title.toLowerCase().includes(skill.split(' ')[0])) {
                    relevanceScore += 20;
                }
            });
            
            // ตรวจสอบคำอธิบายงาน
            resumeSkills.forEach(skill => {
                if (job.description.toLowerCase().includes(skill.split(' ')[0])) {
                    relevanceScore += 10;
                }
            });
            
            return { ...job, relevanceScore };
        }).sort((a, b) => b.relevanceScore - a.relevanceScore);
    }
    
    return allJobs;
}

// Reset Resume Search
function resetResumeSearch() {
    document.getElementById('resume-results').style.display = 'none';
    document.getElementById('resume-file-name').textContent = '';
    document.getElementById('resume-file').value = '';
    document.getElementById('find-jobs-btn').disabled = true;
}

// Helper function to format salary
function formatSalary(salary) {
    if (!salary) return '0';
    return salary.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}