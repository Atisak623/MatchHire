// Language switching functionality
const translations = {
    th: {
        // Navigation
        'nav.home': 'หน้าแรก',
        'nav.jobs': 'ตำแหน่งงาน',
        'nav.profile': 'โปรไฟล์',
        'nav.ai-matching': 'AI Matching',
        'nav.pricing': 'แพ็กเกจราคา',
        'nav.contact': 'ติดต่อเรา',
        'nav.login': 'เข้าสู่ระบบ',
        'nav.register': 'ลงทะเบียน',
        'nav.logout': 'ออกจากระบบ',
        'nav.how-it-works': 'วิธีการใช้งาน',
        'nav.for-employers': 'สำหรับบริษัท',
        'nav.for-job-seekers': 'สำหรับผู้หางาน',
        
        // Hero Section
        'hero.title': 'จับคู่คนเก่ง เข้ากับงานที่ใช่',
        'hero.subtitle': 'แพลตฟอร์มอัจฉริยะสำหรับบริษัทและผู้หางาน ที่ปรับตามความต้องการของคุณแบบเรียลไทม์',
        'hero.start': 'เริ่มต้นใช้งาน',
        'hero.register-company': 'ลงทะเบียนบริษัท',
        'hero.image-alt': 'ภาพประกอบการจับคู่งาน',
        
        // Features Section
        'features.title': 'ทำไมต้องใช้ MatchHire',
        'features.ai-title': 'AI Matching Engine',
        'features.ai-text': 'ระบบเรียนรู้ความต้องการของคุณ เพื่อจับคู่ใบสมัครที่ใช่ในพริบตา',
        'features.fast-title': 'ส่งใบสมัครเร็วทันใจ',
        'features.fast-text': 'Automated Screening ช่วยกรองผู้สมัครตามเกณฑ์ที่ตั้งไว้ในไม่กี่วินาที',
        'features.dashboard-title': 'Dashboard แบบเรียลไทม์',
        'features.dashboard-text': 'เช็คสถานะการสมัครได้ทันที พร้อมสถิติ Performance ของช่องทางสรรหา',
        'features.support-title': 'ทีมงานช่วยเหลือ 24/7',
        'features.support-text': 'บริการดูแลตั้งแต่ตั้งค่าจนถึงเทรนนิ่งทีม HR ใช้งานจริง',
        
        // How It Works
        'how.title': 'ใช้งานง่ายใน 3 ขั้นตอน',
        'how.step1-title': 'สมัครบัญชี & สร้างโปรไฟล์',
        'how.step1-text': 'บริษัทและผู้หางาน ลงทะเบียน กรอกข้อมูลพื้นฐาน เพื่อให้ระบบรู้จักคุณ',
        'how.step2-title': 'อัปโหลด JD หรือ Résumé',
        'how.step2-text': 'ฝ่ายบุคคล ส่ง JD เข้าระบบ หรือผู้หางาน อัปโหลด Résumé เพื่อระบบประมวลผล',
        'how.step3-title': 'รับผล Matching & ติดต่อทันที',
        'how.step3-text': 'ระบบจะแสดงรายชื่อผู้สมัคร/ตำแหน่งที่เหมาะสม พร้อมข้อมูลที่จำเป็นทั้งหมด',
        'how.for-employers': 'เริ่มต้นสำหรับบริษัท',
        'how.for-seekers': 'เริ่มต้นสำหรับผู้หางาน',
        'how.page-title': 'ใช้งานง่ายใน 3 ขั้นตอน',
        'how.page-description': 'วิธีการใช้งาน MatchHire ทั้งสำหรับบริษัทและผู้หางาน เพื่อให้การจับคู่งานเป็นไปอย่างมีประสิทธิภาพ',
        
        // Testimonials
        'testimonials.title': 'เสียงตอบรับจากผู้ใช้งาน',
        'testimonials.1.text': '"MatchHire ทำให้เราเจอคนที่ใช่ ในเวลาไม่ถึงวัน ช่วยลดภาระ HR ได้มากจริง ๆ"',
        'testimonials.1.name': 'คุณอังคณา ศิริสมพร',
        'testimonials.1.title': 'HR Manager, XYZ Solutions',
        'testimonials.2.text': '"ได้งานในฝันเพราะระบบ Matching ของที่นี่ครบครัน แนะนำคอร์สเสริมได้ตรงจุด"',
        'testimonials.2.name': 'นายวิทยา เกียรติชัย',
        'testimonials.2.title': 'Software Engineer, ABC Tech',
        
        // For Employers
        'employers.title': 'สำหรับบริษัท: สรรหาคนที่ใช่ ใน 5 นาที',
        'employers.subtitle': 'AI Matching, Dashboard วิเคราะห์, 24/7 Support',
        'employers.register': 'ลงทะเบียนฟรี',
        'employers.pricing': 'ดูแพ็กเกจราคา',
        
        // For Job Seekers
        'seekers.title': 'สำหรับผู้หางาน: เจออาชีพในฝันได้ง่ายขึ้น',
        'seekers.subtitle': 'ระบบ Matching อัจฉริยะแนะนำงานที่เหมาะกับโปรไฟล์ของคุณ',
        'seekers.register': 'สมัครสมาชิกผู้หางาน',
        'seekers.steps': 'ดูขั้นตอนใช้งาน',
        
        // Contact
        'contact.title': 'ติดต่อเรา',
        'contact.subtitle': 'ยินดีให้คำปรึกษาและสาธิตระบบฟรี',
        'contact.name': 'ชื่อ-นามสกุล',
        'contact.email': 'อีเมล',
        'contact.phone': 'เบอร์โทรศัพท์',
        'contact.message': 'เรื่องที่ต้องการสอบถาม',
        'contact.send': 'ส่งข้อความ',
        'contact.info': 'ข้อมูลติดต่อ',
        'contact.contact-person': 'ชื่อผู้ติดต่อ:',
        'contact.contact-name': 'อธิศักดิ์ ทองดีพุทธ',
        'contact.contact': 'ติดต่อ:',
        'contact.footer-name': 'อธิศักดิ์ ทองดีพุทธ',
        
        // Common
        'common.loading': 'กำลังโหลด...',
        'common.search': 'ค้นหา',
        'common.filter': 'กรอง',
        'common.save': 'บันทึก',
        'common.cancel': 'ยกเลิก',
        'common.close': 'ปิด',
        'common.view': 'ดู',
        'common.edit': 'แก้ไข',
        'common.delete': 'ลบ',
        'common.upload': 'อัปโหลด',
        'common.download': 'ดาวน์โหลด',
        'common.apply': 'สมัคร',
        'common.next': 'ถัดไป',
        'common.previous': 'ก่อนหน้า',
        
        // AI Matching
        'ai.title': 'AI Job Matching System',
        'ai.subtitle': 'ระบบจับคู่ผู้สมัครและตำแหน่งงานด้วย AI แบบอัตโนมัติ ลดเวลาการคัดกรอง เพิ่มคุณภาพการจับคู่',
        'ai.tab1': 'ค้นหางานจาก Resume',
        'ai.tab2': 'ค้นหาผู้สมัครจาก JD',
        'ai.tab3': 'สำรวจตำแหน่งงานทั่วโลก',
        'ai.upload-resume': 'อัปโหลด Resume เพื่อค้นหางานที่เหมาะสม',
        'ai.find-jobs': 'ค้นหางานที่เหมาะสม',
        'ai.analyzing': 'กำลังวิเคราะห์...',
        'ai.skills-detected': 'ทักษะที่ตรวจพบ',
        'ai.experience-analysis': 'ประสบการณ์ที่วิเคราะห์ได้',
        'ai.best-matches': 'ตำแหน่งงานที่เหมาะสมที่สุด',
        'ai.job-details': 'ดูรายละเอียด',
        'ai.apply-job': 'สมัครงาน',
        'ai.source': 'แหล่งที่มา',
        'ai.view-details': 'ดูรายละเอียด',
        'ai.apply-now': 'สมัครทันที',
        'ai.positions-open': 'ตำแหน่งที่เปิดรับ',
        'ai.related-jobs': 'งานที่เกี่ยวข้อง',
        'ai.job-code': 'รหัสตำแหน่งงาน',
        'ai.salary-range': 'ช่วงเงินเดือน',
        'ai.search-jobs': 'ค้นหาตำแหน่งงาน',
        'ai.location-filter': 'กรองตามพื้นที่',
        'ai.job-type': 'กรองตามประเภทการจ้างงาน',
        'ai.experience-level': 'กรองตามประสบการณ์',
        'ai.total-jobs': 'ตำแหน่งงานทั้งหมด',
        'ai.high-match': 'ตำแหน่งที่เข้ากันสูง',
        'ai.avg-score': 'คะแนนเฉลี่ย',
        'ai.upload-title': 'อัปโหลด Resume',
        'ai.upload-instruction': 'ลากและวางไฟล์ที่นี่ หรือคลิกเพื่อเลือกไฟล์\n(รองรับ PDF, DOC, DOCX)',
        'ai.all-areas': 'พื้นที่ทั้งหมด',
        'ai.bangkok': 'กรุงเทพและปริมณฑล',
        'ai.north': 'ภาคเหนือ',
        'ai.northeast': 'ภาคตะวันออกเฉียงเหนือ',
        'ai.east': 'ภาคตะวันออก',
        'ai.west': 'ภาคตะวันตก',
        'ai.south': 'ภาคใต้',
        'ai.remote': 'ทำงานระยะไกล',
        'ai.all-types': 'ประเภทการจ้างงานทั้งหมด',
        'ai.full-time': 'งานประจำ',
        'ai.part-time': 'งานพาร์ทไทม์',
        'ai.contract': 'งานสัญญาจ้าง',
        'ai.freelance': 'ฟรีแลนซ์',
        'ai.all-levels': 'ประสบการณ์ทั้งหมด',
        'ai.entry-level': 'Entry Level (0-1 ปี)',
        'ai.junior-level': 'Junior (1-3 ปี)',
        'ai.mid-level': 'Mid-Level (3-5 ปี)',
        'ai.senior-level': 'Senior (5-8 ปี)',
        'ai.expert-level': 'Expert (8+ ปี)'
    },
    en: {
        // Navigation
        'nav.home': 'Home',
        'nav.jobs': 'Jobs',
        'nav.profile': 'Profile',
        'nav.ai-matching': 'AI Matching',
        'nav.pricing': 'Pricing',
        'nav.contact': 'Contact',
        'nav.login': 'Login',
        'nav.register': 'Register',
        'nav.logout': 'Logout',
        'nav.how-it-works': 'How It Works',
        'nav.for-employers': 'For Employers',
        'nav.for-job-seekers': 'For Job Seekers',
        
        // Hero Section
        'hero.title': 'Match Top Talent with Perfect Jobs',
        'hero.subtitle': 'An intelligent platform for companies and job seekers that adapts to your needs in real-time',
        'hero.start': 'Get Started',
        'hero.register-company': 'Register Company',
        'hero.image-alt': 'Recruitment Matching Illustration',
        
        // Features Section
        'features.title': 'Why Choose MatchHire',
        'features.ai-title': 'AI Matching Engine',
        'features.ai-text': 'Our system learns your preferences to match the right candidates in seconds',
        'features.fast-title': 'Lightning Fast Applications',
        'features.fast-text': 'Automated screening filters candidates based on your criteria within seconds',
        'features.dashboard-title': 'Real-time Dashboard',
        'features.dashboard-text': 'Check application status instantly with performance analytics of your hiring channels',
        'features.support-title': '24/7 Support Team',
        'features.support-text': 'Full service from setup to HR team training for real-world implementation',
        
        // How It Works
        'how.title': 'Simple 3-Step Process',
        'how.step1-title': 'Register & Create Profile',
        'how.step1-text': 'Companies and job seekers register and fill basic information for the system to know you',
        'how.step2-title': 'Upload JD or Resume',
        'how.step2-text': 'HR uploads job descriptions or job seekers upload resumes for system processing',
        'how.step3-title': 'Get Matches & Connect Instantly',
        'how.step3-text': 'System displays matching candidates/positions with all necessary information',
        'how.for-employers': 'Start for Employers',
        'how.for-seekers': 'Start for Job Seekers',
        'how.page-title': 'Easy 3-Step Process',
        'how.page-description': 'How to use MatchHire for both companies and job seekers to make job matching efficient',
        
        // Testimonials
        'testimonials.title': 'User Testimonials',
        'testimonials.1.text': '"MatchHire helped us find the right person in less than a day. It really reduced our HR workload"',
        'testimonials.1.name': 'Angkana Sirisomporn',
        'testimonials.1.title': 'HR Manager, XYZ Solutions',
        'testimonials.2.text': '"Got my dream job because their matching system is comprehensive and recommends relevant courses precisely"',
        'testimonials.2.name': 'Witaya Kiertchai',
        'testimonials.2.title': 'Software Engineer, ABC Tech',
        
        // For Employers
        'employers.title': 'For Companies: Find the Right Talent in 5 Minutes',
        'employers.subtitle': 'AI Matching, Analytics Dashboard, 24/7 Support',
        'employers.register': 'Register Free',
        'employers.pricing': 'View Pricing',
        
        // For Job Seekers
        'seekers.title': 'For Job Seekers: Find Your Dream Career Easier',
        'seekers.subtitle': 'Intelligent matching system recommends jobs that fit your profile perfectly',
        'seekers.register': 'Register as Job Seeker',
        'seekers.steps': 'View Process',
        
        // Contact
        'contact.title': 'Contact Us',
        'contact.subtitle': 'Happy to provide consultation and free system demo',
        'contact.name': 'Full Name',
        'contact.email': 'Email',
        'contact.phone': 'Phone Number',
        'contact.message': 'Your Message',
        'contact.send': 'Send Message',
        'contact.info': 'Contact Information',
        'contact.contact-person': 'Contact Person:',
        'contact.contact-name': 'Atisak Tongdeeput',
        'contact.address': 'Address:',
        'contact.address-detail': '123 Technology Building, 15th Floor\nSukhumvit Road, Bangkok 10110',
        'contact.contact': 'Contact:',
        'contact.footer-name': 'Atisak Tongdeeput',
        
        // Common
        'common.loading': 'Loading...',
        'common.search': 'Search',
        'common.filter': 'Filter',
        'common.save': 'Save',
        'common.cancel': 'Cancel',
        'common.close': 'Close',
        'common.view': 'View',
        'common.edit': 'Edit',
        'common.delete': 'Delete',
        'common.upload': 'Upload',
        'common.download': 'Download',
        'common.apply': 'Apply',
        'common.next': 'Next',
        'common.previous': 'Previous',
        
        // AI Matching
        'ai.title': 'AI Job Matching System',
        'ai.subtitle': 'Automated AI-powered job matching system that reduces screening time and improves match quality',
        'ai.tab1': 'Find Jobs from Resume',
        'ai.tab2': 'Find Candidates from JD',
        'ai.tab3': 'Explore Global Job Positions',
        'ai.upload-resume': 'Upload Resume to Find Suitable Jobs',
        'ai.find-jobs': 'Find Suitable Jobs',
        'ai.analyzing': 'Analyzing...',
        'ai.skills-detected': 'Skills Detected',
        'ai.experience-analysis': 'Experience Analysis',
        'ai.best-matches': 'Best Job Matches',
        'ai.job-details': 'View Details',
        'ai.apply-job': 'Apply Job',
        'ai.source': 'Source',
        'ai.view-details': 'View Details',
        'ai.apply-now': 'Apply Now',
        'ai.positions-open': 'Open Positions',
        'ai.related-jobs': 'Related Jobs',
        'ai.job-code': 'Job Code',
        'ai.salary-range': 'Salary Range',
        'ai.search-jobs': 'Search Jobs',
        'ai.location-filter': 'Filter by Location',
        'ai.job-type': 'Job Type',
        'ai.experience-level': 'Experience Level',
        'ai.total-jobs': 'Total Jobs',
        'ai.high-match': 'High Match Positions',
        'ai.avg-score': 'Average Score',
        'ai.upload-title': 'Upload Resume',
        'ai.upload-instruction': 'Drag and drop files here, or click to select\n(Supports PDF, DOC, DOCX)',
        'ai.all-areas': 'All Areas',
        'ai.bangkok': 'Bangkok and Vicinity',
        'ai.north': 'Northern Region',
        'ai.northeast': 'Northeastern Region',
        'ai.east': 'Eastern Region',
        'ai.west': 'Western Region',
        'ai.south': 'Southern Region',
        'ai.remote': 'Remote Work',
        'ai.all-types': 'All Types',
        'ai.full-time': 'Full Time',
        'ai.part-time': 'Part Time',
        'ai.contract': 'Contract',
        'ai.freelance': 'Freelance',
        'ai.all-levels': 'All Levels',
        'ai.entry-level': 'Entry Level (0-1 years)',
        'ai.junior-level': 'Junior (1-3 years)',
        'ai.mid-level': 'Mid-Level (3-5 years)',
        'ai.senior-level': 'Senior (5-8 years)',
        'ai.expert-level': 'Expert (8+ years)',
        
        // Categories Section
        'categories.title': 'Popular Jobs (from LinkedIn Data)',
        
        // Hot Positions Section
        'hot-positions.title': 'Hot Positions Most Organizations Want to Recruit',
        'hot-positions.subtitle': 'Positions with the highest job openings on LinkedIn in 2024-2025',
        
        // Features Section Update
        'features.subtitle': 'Because we help you find the right jobs and candidates with cutting-edge AI technology',
        
        // Job Seeker Features
        'seekers.feature1-title': 'Resume Optimization',
        'seekers.feature1-text': 'Recommend keywords that match your desired jobs',
        'seekers.feature2-title': 'Skill Gap Analysis',
        'seekers.feature2-text': 'Identify skills needed to get closer to your dream job',
        'seekers.feature3-title': 'Interview Scheduler',
        'seekers.feature3-text': 'Automated interview booking with Career Insights'
    }
};

// Language management
class LanguageManager {
    constructor() {
        this.currentLanguage = localStorage.getItem('language') || 'th';
        this.init();
    }
    
    init() {
        this.updateLanguageToggle();
        this.translatePage();
        this.bindEvents();
    }
    
    bindEvents() {
        // Language toggle button
        const langToggle = document.getElementById('language-toggle');
        if (langToggle) {
            langToggle.addEventListener('click', () => {
                this.toggleLanguage();
            });
        }
    }
    
    toggleLanguage() {
        this.currentLanguage = this.currentLanguage === 'th' ? 'en' : 'th';
        localStorage.setItem('language', this.currentLanguage);
        this.updateLanguageToggle();
        this.translatePage();
    }
    
    updateLanguageToggle() {
        const langToggle = document.getElementById('language-toggle');
        if (langToggle) {
            langToggle.textContent = this.currentLanguage === 'th' ? 'EN' : 'TH';
            langToggle.setAttribute('data-lang', this.currentLanguage === 'th' ? 'en' : 'th');
        }
    }
    
    translatePage() {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.getTranslation(key);
            if (translation) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translation;
                } else {
                    element.textContent = translation;
                }
            }
        });
        
        // Update document language
        document.documentElement.lang = this.currentLanguage;
    }
    
    getTranslation(key) {
        return translations[this.currentLanguage]?.[key] || key;
    }
    
    getCurrentLanguage() {
        return this.currentLanguage;
    }
}

// Initialize language manager
document.addEventListener('DOMContentLoaded', function() {
    window.languageManager = new LanguageManager();
});

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { LanguageManager, translations };
}