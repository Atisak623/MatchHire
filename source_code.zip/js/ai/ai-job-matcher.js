/**
 * AI Job Matcher
 * 
 * โมดูลหลักสำหรับการจับคู่ระหว่างเรซูเม่กับตำแหน่งงาน
 * ใช้ข้อมูลสังเคราะห์และโมเดล ML ที่ผ่านการฝึกฝนแล้ว
 */

class AIJobMatcher {
    constructor() {
        // สร้าง instance ของ SyntheticDataGenerator
        this.dataGenerator = syntheticDataGenerator;
        
        // สร้าง instance ของ FeatureEngineering
        this.featureEngineering = featureEngineering;
        
        // สร้าง instance ของโมเดล
        this.logisticRegressionModel = logisticRegressionModel;
        this.randomForestModel = randomForestModel;
        this.ensembleModel = ensembleModel;
        
        // เลือกโมเดลที่จะใช้เป็นค่าเริ่มต้น
        this.activeModel = this.ensembleModel;
        
        // สร้างข้อมูลสังเคราะห์
        this.syntheticData = this.dataGenerator.generateAllData();
        
        // ประมวลผล corpus สำหรับ TF-IDF
        this.prepareCorpus();
    }
    
    /**
     * เตรียม corpus สำหรับ TF-IDF
     */
    prepareCorpus() {
        // รวมข้อความจากเรซูเม่และงานทั้งหมด
        const allTexts = [];
        
        // เพิ่มข้อความจากเรซูเม่
        for (const resume of this.syntheticData.resumes) {
            allTexts.push(resume.text);
        }
        
        // เพิ่มข้อความจากงาน
        for (const job of this.syntheticData.jobs) {
            const jobText = `${job.title} requiring ${job.requiredSkills.join(', ')} with minimum ${job.minExp} years of experience.`;
            allTexts.push(jobText);
        }
        
        // fit TF-IDF
        this.featureEngineering.fitTFIDF(allTexts);
    }
    
    /**
     * แปลงข้อมูลเรซูเม่ดิบให้เป็นเรซูเม่ที่พร้อมใช้งาน
     * @param {Object} resumeData ข้อมูลเรซูเม่ดิบ
     * @returns {Object} เรซูเม่ที่พร้อมใช้งาน
     */
    processResumeData(resumeData) {
        // กรณีที่เป็นข้อมูลจากการอัปโหลดไฟล์
        if (resumeData.parsedContent) {
            const skills = this.extractSkillsFromText(resumeData.parsedContent);
            const yearsExp = this.extractYearsFromText(resumeData.parsedContent);
            const education = this.extractEducationFromText(resumeData.parsedContent);
            const eduOrd = this.featureEngineering.getEducationOrdinal(education);
            
            return {
                text: resumeData.parsedContent,
                skills: skills,
                yearsExp: yearsExp,
                education: education,
                eduOrd: eduOrd
            };
        }
        
        // กรณีที่เป็นข้อมูลจากการกรอกฟอร์ม
        return {
            text: resumeData.text || resumeData.summary || '',
            skills: resumeData.skills || [],
            yearsExp: resumeData.yearsExp || 0,
            education: resumeData.education || 'Bachelor',
            eduOrd: resumeData.eduOrd || this.featureEngineering.getEducationOrdinal(resumeData.education || 'Bachelor')
        };
    }
    
    /**
     * แปลงข้อมูลงานดิบให้เป็นงานที่พร้อมใช้งาน
     * @param {Object} jobData ข้อมูลงานดิบ
     * @returns {Object} งานที่พร้อมใช้งาน
     */
    processJobData(jobData) {
        // กรณีที่เป็นข้อมูลจากการอัปโหลดไฟล์
        if (jobData.parsedContent) {
            const skills = this.extractSkillsFromText(jobData.parsedContent);
            const minExp = this.extractYearsFromText(jobData.parsedContent);
            const minEdu = this.extractEducationFromText(jobData.parsedContent);
            
            return {
                title: jobData.title || 'Job Position',
                requiredSkills: skills,
                minExp: minExp,
                minEdu: minEdu
            };
        }
        
        // กรณีที่เป็นข้อมูลจากการกรอกฟอร์ม
        return {
            title: jobData.title || 'Job Position',
            requiredSkills: jobData.requiredSkills || [],
            minExp: jobData.minExp || 0,
            minEdu: jobData.minEdu || 'Bachelor'
        };
    }
    
    /**
     * สกัดทักษะจากข้อความ
     * @param {string} text ข้อความ
     * @returns {Array} รายการทักษะที่พบ
     */
    extractSkillsFromText(text) {
        const skills = [];
        const textLower = text.toLowerCase();
        
        // ตรวจสอบทักษะจากรายการทักษะทั้งหมด
        for (const skill of this.dataGenerator.allSkills) {
            if (textLower.includes(skill.toLowerCase())) {
                skills.push(skill);
            }
        }
        
        return skills;
    }
    
    /**
     * สกัดปีประสบการณ์จากข้อความ
     * @param {string} text ข้อความ
     * @returns {number} จำนวนปีประสบการณ์
     */
    extractYearsFromText(text) {
        const matches = text.match(/(\d+)\s*(?:years?|yr|yrs?)/i);
        if (matches && matches[1]) {
            return parseInt(matches[1]);
        }
        
        // ตรวจสอบกรณีที่เป็นระดับประสบการณ์
        if (text.match(/senior|lead|head|director|manager/i)) {
            return 5;
        } else if (text.match(/mid|intermediate/i)) {
            return 3;
        } else if (text.match(/junior|entry/i)) {
            return 1;
        }
        
        return 0;
    }
    
    /**
     * สกัดระดับการศึกษาจากข้อความ
     * @param {string} text ข้อความ
     * @returns {string} ระดับการศึกษา
     */
    extractEducationFromText(text) {
        const textLower = text.toLowerCase();
        
        if (textLower.match(/phd|doctorate|doctoral/)) {
            return 'PhD';
        } else if (textLower.match(/master|msc|ma|ms/)) {
            return 'Master';
        } else if (textLower.match(/bachelor|bsc|ba|bs/)) {
            return 'Bachelor';
        }
        
        return 'Bachelor'; // ค่าเริ่มต้น
    }
    
    /**
     * จับคู่เรซูเม่กับตำแหน่งงานที่มีอยู่ทั้งหมด
     * @param {Object} resumeData ข้อมูลเรซูเม่
     * @returns {Array} รายการงานที่เหมาะสมพร้อมคะแนน
     */
    async matchResumeWithAllJobs(resumeData) {
        // แปลงข้อมูลเรซูเม่
        const resume = this.processResumeData(resumeData);
        
        // จับคู่กับงานทั้งหมด (ทั้งที่มีอยู่และงานสังเคราะห์)
        const jobMatches = [];
        
        try {
            // ดึงข้อมูลงานจากเว็บไซต์งานจริง (JobThai, JobBKK, JobsDB, Job topgun, LinkedIn)
            if (typeof jobSiteConnector !== 'undefined') {
                const realJobs = await jobSiteConnector.matchResumeWithRealJobs(resume);
                
                for (const realJob of realJobs) {
                    // แปลงข้อมูลงานจริงให้อยู่ในรูปแบบที่ต้องการ
                    const job = {
                        id: realJob.id,
                        title: realJob.title,
                        requiredSkills: realJob.requirements || this.extractSkillsFromText(realJob.description || ''),
                        minExp: this.extractYearsFromText(realJob.description || ''),
                        minEdu: 'Bachelor',
                        source: realJob.source,
                        company: realJob.company,
                        location: realJob.location || 'Thailand',
                        salary: realJob.salary || 'N/A',
                        sourceUrl: realJob.externalUrl,
                        originalJob: realJob
                    };
                    
                    // สกัด features
                    const features = this.featureEngineering.extractAllFeatures(resume, job);
                    
                    // ทำนายคะแนนและรายละเอียด
                    const predictions = this.activeModel.getDetailedPredictions(features);
                    
                    // เพิ่มเข้าในรายการจับคู่
                    jobMatches.push({
                        job: job,
                        features: features,
                        score: predictions.ensemble.score,
                        predictions: predictions,
                        isMatch: predictions.ensemble.prediction === 1,
                        isRealJob: true
                    });
                }
            }
            
            // ถ้ามีงานจริงใน jobIntegrationsReal
            if (typeof jobIntegrationsReal !== 'undefined') {
                // ดึงงานจาก LinkedIn
                try {
                    const realJobs = await jobIntegrationsReal.getAllRealJobs();
                    
                    for (const realJob of realJobs) {
                        // แปลงข้อมูลงานจริงให้อยู่ในรูปแบบที่ต้องการ
                        const job = {
                            id: realJob.id,
                            title: realJob.title,
                            requiredSkills: realJob.requirements || this.extractSkillsFromText(realJob.description || ''),
                            minExp: this.extractYearsFromText(realJob.description || ''),
                            minEdu: 'Bachelor',
                            source: realJob.source,
                            company: realJob.company,
                            location: realJob.location,
                            salary: `${realJob.salaryMin}-${realJob.salaryMax}`,
                            sourceUrl: realJob.sourceUrl,
                            originalJob: realJob
                        };
                        
                        // สกัด features
                        const features = this.featureEngineering.extractAllFeatures(resume, job);
                        
                        // ทำนายคะแนนและรายละเอียด
                        const predictions = this.activeModel.getDetailedPredictions(features);
                        
                        // เพิ่มเข้าในรายการจับคู่
                        jobMatches.push({
                            job: job,
                            features: features,
                            score: predictions.ensemble.score,
                            predictions: predictions,
                            isMatch: predictions.ensemble.prediction === 1
                        });
                    }
                } catch (error) {
                    console.error('Error fetching LinkedIn jobs:', error);
                }
            }
        } catch (error) {
            console.error('Error matching with real jobs:', error);
        }
        
        // จับคู่กับงานสังเคราะห์
        for (const syntheticJob of this.syntheticData.jobs) {
            // สกัด features
            const features = this.featureEngineering.extractAllFeatures(resume, syntheticJob);
            
            // ทำนายคะแนนและรายละเอียด
            const predictions = this.activeModel.getDetailedPredictions(features);
            
            // เพิ่มเข้าในรายการจับคู่
            jobMatches.push({
                job: syntheticJob,
                features: features,
                score: predictions.ensemble.score,
                predictions: predictions,
                isMatch: predictions.ensemble.prediction === 1,
                isSynthetic: true
            });
        }
        
        // เรียงลำดับตามคะแนน
        jobMatches.sort((a, b) => b.score - a.score);
        
        return jobMatches;
    }
    
    /**
     * จับคู่งานกับเรซูเม่ที่มีอยู่ทั้งหมด
     * @param {Object} jobData ข้อมูลงาน
     * @returns {Array} รายการเรซูเม่ที่เหมาะสมพร้อมคะแนน
     */
    matchJobWithAllResumes(jobData) {
        // แปลงข้อมูลงาน
        const job = this.processJobData(jobData);
        
        // จับคู่กับเรซูเม่ทั้งหมด (เฉพาะข้อมูลสังเคราะห์)
        const resumeMatches = [];
        
        for (const syntheticResume of this.syntheticData.resumes) {
            // สกัด features
            const features = this.featureEngineering.extractAllFeatures(syntheticResume, job);
            
            // ทำนายคะแนนและรายละเอียด
            const predictions = this.activeModel.getDetailedPredictions(features);
            
            // เพิ่มเข้าในรายการจับคู่
            resumeMatches.push({
                resume: syntheticResume,
                features: features,
                score: predictions.ensemble.score,
                predictions: predictions,
                isMatch: predictions.ensemble.prediction === 1
            });
        }
        
        // เรียงลำดับตามคะแนน
        resumeMatches.sort((a, b) => b.score - a.score);
        
        return resumeMatches;
    }
    
    /**
     * เปลี่ยนโมเดลที่ใช้งานอยู่
     * @param {string} modelName ชื่อโมเดล
     */
    setActiveModel(modelName) {
        switch (modelName) {
            case 'logistic':
                this.activeModel = this.logisticRegressionModel;
                break;
            case 'randomForest':
                this.activeModel = this.randomForestModel;
                break;
            case 'ensemble':
            default:
                this.activeModel = this.ensembleModel;
                break;
        }
    }
    
    /**
     * วิเคราะห์จุดอ่อนและจุดแข็งของเรซูเม่
     * @param {Object} resumeData ข้อมูลเรซูเม่
     * @param {Object} jobData ข้อมูลงาน
     * @returns {Object} ผลการวิเคราะห์
     */
    analyzeResumeStrengthsWeaknesses(resumeData, jobData) {
        // แปลงข้อมูล
        const resume = this.processResumeData(resumeData);
        const job = this.processJobData(jobData);
        
        // สกัด features
        const features = this.featureEngineering.extractAllFeatures(resume, job);
        
        // ดึงข้อมูลความสำคัญของฟีเจอร์
        const featureImportance = this.logisticRegressionModel.getFeatureImportance(features);
        
        // วิเคราะห์จุดแข็ง
        const strengths = featureImportance
            .filter(f => f.impact === 'positive' && f.contribution > 0.5)
            .map(f => ({
                feature: f.feature,
                value: f.value,
                contribution: f.contribution
            }));
        
        // วิเคราะห์จุดอ่อน
        const weaknesses = featureImportance
            .filter(f => f.impact === 'negative' || f.contribution < 0.2)
            .map(f => ({
                feature: f.feature,
                value: f.value,
                contribution: f.contribution
            }));
        
        // วิเคราะห์ทักษะที่ขาด
        const missingSkills = job.requiredSkills.filter(skill => 
            !resume.skills.some(s => s.toLowerCase() === skill.toLowerCase())
        );
        
        // ข้อเสนอแนะในการปรับปรุง
        const recommendations = [];
        
        // ถ้ามีทักษะที่ขาด
        if (missingSkills.length > 0) {
            recommendations.push({
                type: 'skills',
                message: `เพิ่มทักษะ: ${missingSkills.join(', ')}`
            });
        }
        
        // ถ้าประสบการณ์น้อยกว่าที่ต้องการ
        if (resume.yearsExp < job.minExp) {
            recommendations.push({
                type: 'experience',
                message: `เพิ่มประสบการณ์อีก ${job.minExp - resume.yearsExp} ปี หรือเน้นโครงการที่เกี่ยวข้องมากขึ้น`
            });
        }
        
        return {
            strengths: strengths,
            weaknesses: weaknesses,
            missingSkills: missingSkills,
            recommendations: recommendations,
            features: features
        };
    }
}

// สร้าง instance ของ AIJobMatcher
const aiJobMatcher = new AIJobMatcher();