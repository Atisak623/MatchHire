/**
 * Machine Learning Models for Job Matching
 * จำลองโมเดล Machine Learning สำหรับการจับคู่งาน
 */

class LogisticRegressionModel {
    constructor() {
        // ค่าสัมประสิทธิ์ที่ได้จากการฝึกโมเดล (จำลองจากข้อมูลที่ได้จากการฝึก)
        this.coefficients = {
            cosSim: 1.8,
            jaccardSkill: 3.5,
            missingSkills: -3.4,
            yearsExp: 0.15,
            eduOrd: 0.30,
            resumeLen: -1.0,
            avgWordLen: 0.8
        };
        
        // Intercept (ค่าคงที่)
        this.intercept = -2.1;
        
        // รายการ features ที่ใช้ในโมเดล
        this.featureNames = ['cosSim', 'jaccardSkill', 'missingSkills', 'yearsExp', 'eduOrd', 'resumeLen', 'avgWordLen'];
        
        // Metrics ที่ได้จากการประเมินโมเดล
        this.metrics = {
            aucRoc: 0.99,
            precision: 0.89,
            recall: 0.50
        };
    }
    
    /**
     * ทำนายความน่าจะเป็นของการ Match
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} ความน่าจะเป็นของการ Match (0-1)
     */
    predict(features) {
        // คำนวณ linear combination
        let linearCombination = this.intercept;
        
        for (const featureName of this.featureNames) {
            linearCombination += this.coefficients[featureName] * (features[featureName] || 0);
        }
        
        // ใช้ sigmoid function เพื่อแปลงเป็นความน่าจะเป็น
        return this.sigmoid(linearCombination);
    }
    
    /**
     * Sigmoid function
     * @param {number} x ค่า input
     * @returns {number} ค่าที่ผ่าน sigmoid (0-1)
     */
    sigmoid(x) {
        return 1 / (1 + Math.exp(-x));
    }
    
    /**
     * ทำนายคลาส (Match หรือ Not Match)
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} 1 คือ Match, 0 คือ Not Match
     */
    predictClass(features) {
        const probability = this.predict(features);
        return probability >= 0.5 ? 1 : 0;
    }
    
    /**
     * ได้รับคะแนนความน่าจะเป็นในรูปแบบเปอร์เซ็นต์
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} คะแนนเปอร์เซ็นต์ (0-100)
     */
    getMatchScore(features) {
        return Math.round(this.predict(features) * 100);
    }
    
    /**
     * วิเคราะห์ความสำคัญของแต่ละฟีเจอร์
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {Array} รายการฟีเจอร์พร้อมความสำคัญ
     */
    getFeatureImportance(features) {
        const importance = [];
        
        for (const featureName of this.featureNames) {
            const contribution = Math.abs(this.coefficients[featureName] * (features[featureName] || 0));
            importance.push({
                feature: featureName,
                coefficient: this.coefficients[featureName],
                value: features[featureName] || 0,
                contribution: contribution,
                impact: this.coefficients[featureName] > 0 ? 'positive' : 'negative'
            });
        }
        
        // เรียงลำดับตามความสำคัญ
        importance.sort((a, b) => b.contribution - a.contribution);
        
        return importance;
    }
}

class RandomForestModel {
    constructor() {
        // Feature importance ที่ได้จากการฝึกโมเดล Random Forest
        this.featureImportance = {
            jaccardSkill: 0.52,
            cosSim: 0.18,
            missingSkills: 0.12,
            yearsExp: 0.10,
            eduOrd: 0.05,
            resumeLen: 0.02,
            avgWordLen: 0.01
        };
        
        // รายการ features ที่ใช้ในโมเดล
        this.featureNames = ['cosSim', 'jaccardSkill', 'missingSkills', 'yearsExp', 'eduOrd', 'resumeLen', 'avgWordLen'];
        
        // Metrics ที่ได้จากการประเมินโมเดล
        this.metrics = {
            aucRoc: 1.00,
            precision: 0.94,
            recall: 1.00
        };
        
        // จำลอง decision trees (ใช้กฎง่ายๆ)
        this.trees = this.createSimpleTrees();
    }
    
    /**
     * สร้าง decision trees แบบง่าย
     * @returns {Array} รายการของ decision trees
     */
    createSimpleTrees() {
        return [
            // Tree 1: เน้น jaccard similarity
            {
                predict: (features) => {
                    if (features.jaccardSkill >= 0.4) {
                        return features.yearsExp >= 2 ? 0.9 : 0.7;
                    } else {
                        return features.cosSim >= 0.3 ? 0.4 : 0.2;
                    }
                }
            },
            // Tree 2: เน้น missing skills
            {
                predict: (features) => {
                    if (features.missingSkills <= 1) {
                        return features.jaccardSkill >= 0.3 ? 0.8 : 0.6;
                    } else {
                        return features.cosSim >= 0.4 ? 0.5 : 0.3;
                    }
                }
            },
            // Tree 3: เน้น cosine similarity
            {
                predict: (features) => {
                    if (features.cosSim >= 0.5) {
                        return features.yearsExp >= 3 ? 0.85 : 0.7;
                    } else {
                        return features.jaccardSkill >= 0.5 ? 0.6 : 0.4;
                    }
                }
            },
            // Tree 4: เน้น experience และ education
            {
                predict: (features) => {
                    if (features.yearsExp >= 4 && features.eduOrd >= 2) {
                        return 0.8;
                    } else if (features.yearsExp >= 2 || features.eduOrd >= 1) {
                        return features.jaccardSkill >= 0.3 ? 0.6 : 0.4;
                    } else {
                        return 0.3;
                    }
                }
            },
            // Tree 5: เน้น combination
            {
                predict: (features) => {
                    const combinedScore = (features.jaccardSkill * 0.5) + (features.cosSim * 0.3) - (features.missingSkills * 0.1);
                    return Math.max(0.1, Math.min(0.9, combinedScore));
                }
            }
        ];
    }
    
    /**
     * ทำนายความน่าจะเป็นของการ Match
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} ความน่าจะเป็นของการ Match (0-1)
     */
    predict(features) {
        // ใช้ ensemble ของ trees ทั้งหมด
        let totalPrediction = 0;
        
        for (const tree of this.trees) {
            totalPrediction += tree.predict(features);
        }
        
        // หาค่าเฉลี่ย
        return totalPrediction / this.trees.length;
    }
    
    /**
     * ทำนายคลาส (Match หรือ Not Match)
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} 1 คือ Match, 0 คือ Not Match
     */
    predictClass(features) {
        const probability = this.predict(features);
        return probability >= 0.5 ? 1 : 0;
    }
    
    /**
     * ได้รับคะแนนความน่าจะเป็นในรูปแบบเปอร์เซ็นต์
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} คะแนนเปอร์เซ็นต์ (0-100)
     */
    getMatchScore(features) {
        return Math.round(this.predict(features) * 100);
    }
    
    /**
     * ได้รับความสำคัญของฟีเจอร์
     * @returns {Array} รายการฟีเจอร์พร้อมความสำคัญ
     */
    getFeatureImportanceRanking() {
        const importance = [];
        
        for (const featureName of this.featureNames) {
            importance.push({
                feature: featureName,
                importance: this.featureImportance[featureName] || 0
            });
        }
        
        // เรียงลำดับตามความสำคัญ
        importance.sort((a, b) => b.importance - a.importance);
        
        return importance;
    }
}

/**
 * Model Ensemble สำหรับรวมผลลัพธ์จากหลายโมเดล
 */
class EnsembleModel {
    constructor() {
        this.logisticRegression = new LogisticRegressionModel();
        this.randomForest = new RandomForestModel();
        
        // น้ำหนักของแต่ละโมเดล
        this.weights = {
            logistic: 0.4,
            randomForest: 0.6
        };
    }
    
    /**
     * ทำนายโดยใช้ ensemble ของทั้งสองโมเดล
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} ความน่าจะเป็นของการ Match (0-1)
     */
    predict(features) {
        const lrPrediction = this.logisticRegression.predict(features);
        const rfPrediction = this.randomForest.predict(features);
        
        // weighted average
        return (lrPrediction * this.weights.logistic) + (rfPrediction * this.weights.randomForest);
    }
    
    /**
     * ได้รับคะแนนความน่าจะเป็นในรูปแบบเปอร์เซ็นต์
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} คะแนนเปอร์เซ็นต์ (0-100)
     */
    getMatchScore(features) {
        return Math.round(this.predict(features) * 100);
    }
    
    /**
     * ทำนายคลาส (Match หรือ Not Match)
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {number} 1 คือ Match, 0 คือ Not Match
     */
    predictClass(features) {
        const probability = this.predict(features);
        return probability >= 0.5 ? 1 : 0;
    }
    
    /**
     * ได้รับผลลัพธ์จากทั้งสองโมเดล
     * @param {Object} features ฟีเจอร์ทั้งหมด
     * @returns {Object} ผลลัพธ์จากทั้งสองโมเดล
     */
    getDetailedPredictions(features) {
        return {
            ensemble: {
                score: this.getMatchScore(features),
                probability: this.predict(features),
                prediction: this.predictClass(features)
            },
            logisticRegression: {
                score: this.logisticRegression.getMatchScore(features),
                probability: this.logisticRegression.predict(features),
                prediction: this.logisticRegression.predictClass(features),
                featureImportance: this.logisticRegression.getFeatureImportance(features)
            },
            randomForest: {
                score: this.randomForest.getMatchScore(features),
                probability: this.randomForest.predict(features),
                prediction: this.randomForest.predictClass(features),
                featureImportance: this.randomForest.getFeatureImportanceRanking()
            }
        };
    }
}

// สร้าง instances ของโมเดลต่างๆ
const logisticRegressionModel = new LogisticRegressionModel();
const randomForestModel = new RandomForestModel();
const ensembleModel = new EnsembleModel();