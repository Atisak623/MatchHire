/**
 * Feature Engineering for Job Matching
 * สร้างคุณลักษณะจากข้อมูลดิบสำหรับการจับคู่งาน
 */

class FeatureEngineering {
    constructor() {
        this.allWords = new Set(); // เก็บคำทั้งหมดที่พบใน corpus
        this.idfValues = {}; // เก็บค่า IDF ของแต่ละคำ
        this.corpus = []; // เก็บเอกสารทั้งหมด (resume + job)
    }
    
    /**
     * ประมวลผลข้อความทั้งหมดเพื่อสร้าง TF-IDF
     * @param {Array} documents รายการข้อความทั้งหมด
     */
    fitTFIDF(documents) {
        this.corpus = documents;
        
        // รวบรวมคำทั้งหมด
        for (const doc of documents) {
            const words = this.tokenize(doc);
            for (const word of words) {
                this.allWords.add(word);
            }
        }
        
        // คำนวณค่า IDF
        const N = documents.length;
        for (const word of this.allWords) {
            let documentFrequency = 0;
            for (const doc of documents) {
                if (doc.toLowerCase().includes(word)) {
                    documentFrequency++;
                }
            }
            this.idfValues[word] = Math.log(N / (1 + documentFrequency));
        }
    }
    
    /**
     * แปลงข้อความเป็น TF-IDF vector
     * @param {string} text ข้อความที่ต้องการแปลง
     * @returns {Object} TF-IDF vector ในรูปแบบ object
     */
    transformToTFIDF(text) {
        const words = this.tokenize(text);
        const wordCount = {};
        const vector = {};
        
        // นับจำนวนคำ (TF)
        for (const word of words) {
            wordCount[word] = (wordCount[word] || 0) + 1;
        }
        
        // คำนวณ TF-IDF
        for (const word in wordCount) {
            if (this.idfValues[word]) {
                const tf = wordCount[word] / words.length;
                vector[word] = tf * this.idfValues[word];
            }
        }
        
        return vector;
    }
    
    /**
     * คำนวณ cosine similarity ระหว่าง 2 vectors
     * @param {Object} vectorA vector แรก
     * @param {Object} vectorB vector ที่สอง
     * @returns {number} ค่า cosine similarity
     */
    calculateCosineSimilarity(vectorA, vectorB) {
        // หาจุดตัดของคำที่มีในทั้งสอง vectors
        const commonWords = Object.keys(vectorA).filter(word => vectorB[word] !== undefined);
        
        // ถ้าไม่มีคำร่วมกันเลย
        if (commonWords.length === 0) {
            return 0;
        }
        
        // คำนวณ dot product
        let dotProduct = 0;
        for (const word of commonWords) {
            dotProduct += vectorA[word] * vectorB[word];
        }
        
        // คำนวณขนาดของ vectors
        const magnitudeA = Math.sqrt(Object.values(vectorA).reduce((sum, val) => sum + val * val, 0));
        const magnitudeB = Math.sqrt(Object.values(vectorB).reduce((sum, val) => sum + val * val, 0));
        
        // ป้องกันการหารด้วยศูนย์
        if (magnitudeA === 0 || magnitudeB === 0) {
            return 0;
        }
        
        // คำนวณ cosine similarity
        return dotProduct / (magnitudeA * magnitudeB);
    }
    
    /**
     * แยกคำจากข้อความ
     * @param {string} text ข้อความ
     * @returns {Array} รายการคำที่แยกแล้ว
     */
    tokenize(text) {
        // แปลงเป็นตัวพิมพ์เล็ก และแยกคำโดยใช้เครื่องหมายและช่องว่าง
        return text.toLowerCase()
            .replace(/[^\w\s]/g, ' ') // แทนที่เครื่องหมายด้วยช่องว่าง
            .split(/\s+/) // แยกด้วยช่องว่าง
            .filter(word => word.length > 1); // กรองคำที่สั้นเกินไป
    }
    
    /**
     * คำนวณค่า Jaccard Similarity ระหว่าง 2 เซต
     * @param {Array} setA เซตแรก
     * @param {Array} setB เซตที่สอง
     * @returns {number} ค่า Jaccard Similarity
     */
    calculateJaccardSimilarity(setA, setB) {
        const a = new Set(setA);
        const b = new Set(setB);
        
        // หาจำนวนสมาชิกที่ซ้ำกัน (intersection)
        const intersection = new Set([...a].filter(x => b.has(x)));
        
        // หาจำนวนสมาชิกทั้งหมดโดยไม่นับซ้ำ (union)
        const union = new Set([...a, ...b]);
        
        // คำนวณ Jaccard = |A ∩ B| / |A ∪ B|
        return intersection.size / union.size;
    }
    
    /**
     * คำนวณจำนวนทักษะที่ขาดไป
     * @param {Array} resumeSkills ทักษะในเรซูเม่
     * @param {Array} jobSkills ทักษะที่ต้องการในงาน
     * @returns {number} จำนวนทักษะที่ขาดไป
     */
    calculateMissingSkills(resumeSkills, jobSkills) {
        const resumeSkillsSet = new Set(resumeSkills.map(s => s.toLowerCase()));
        const jobSkillsSet = new Set(jobSkills.map(s => s.toLowerCase()));
        
        // หาทักษะที่ขาดไป = jobSkills - resumeSkills
        const missingSkills = [...jobSkillsSet].filter(skill => !resumeSkillsSet.has(skill));
        
        return missingSkills.length;
    }
    
    /**
     * วิเคราะห์คุณภาพของข้อความเรซูเม่
     * @param {string} text ข้อความเรซูเม่
     * @returns {Object} คุณภาพของข้อความ
     */
    analyzeResumeQuality(text) {
        const words = this.tokenize(text);
        
        // คำนวณความยาวเฉลี่ยของคำ
        const avgWordLength = text.replace(/[^\w]/g, '').length / words.length;
        
        return {
            resumeLen: words.length,
            avgWordLen: avgWordLength
        };
    }
    
    /**
     * แปลงระดับการศึกษาเป็นค่าตัวเลข
     * @param {string} education ระดับการศึกษา
     * @returns {number} ค่าตัวเลขของระดับการศึกษา
     */
    getEducationOrdinal(education) {
        const educationMap = {
            'bachelor': 1,
            'master': 2,
            'phd': 3,
            'doctorate': 3
        };
        
        // ลองหาจาก keywords ใน education string
        for (const [keyword, value] of Object.entries(educationMap)) {
            if (education.toLowerCase().includes(keyword)) {
                return value;
            }
        }
        
        return 0; // ไม่สามารถระบุได้
    }
    
    /**
     * สร้าง features ทั้งหมดจากเรซูเม่และงาน
     * @param {Object} resume ข้อมูลเรซูเม่
     * @param {Object} job ข้อมูลงาน
     * @returns {Object} features ทั้งหมด
     */
    extractAllFeatures(resume, job) {
        // สร้าง text ของ job
        const jobText = `${job.title} requiring ${job.requiredSkills.join(', ')} with minimum ${job.minExp} years of experience.`;
        
        // คำนวณ TF-IDF cosine similarity
        const resumeVector = this.transformToTFIDF(resume.text);
        const jobVector = this.transformToTFIDF(jobText);
        const cosSim = this.calculateCosineSimilarity(resumeVector, jobVector);
        
        // คำนวณ Jaccard similarity
        const jaccardSkill = this.calculateJaccardSimilarity(resume.skills, job.requiredSkills);
        
        // คำนวณจำนวนทักษะที่ขาดไป
        const missingSkills = this.calculateMissingSkills(resume.skills, job.requiredSkills);
        
        // วิเคราะห์คุณภาพของเรซูเม่
        const qualityMetrics = this.analyzeResumeQuality(resume.text);
        
        // รวม features ทั้งหมด
        return {
            cosSim: cosSim,
            jaccardSkill: jaccardSkill,
            missingSkills: missingSkills,
            yearsExp: resume.yearsExp,
            eduOrd: resume.eduOrd || this.getEducationOrdinal(resume.education),
            resumeLen: qualityMetrics.resumeLen,
            avgWordLen: qualityMetrics.avgWordLen
        };
    }
}

// สร้าง instance ของ FeatureEngineering
const featureEngineering = new FeatureEngineering();