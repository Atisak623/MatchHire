/**
 * Job Site Connections
 * 
 * Connects AI matching with real job sites like JobThai, JobBKK, JobsDB, Job topgun, and LinkedIn
 */

class JobSiteConnector {
    constructor() {
        this.jobSites = [
            {
                name: 'LinkedIn',
                baseUrl: 'https://www.linkedin.com/jobs/search/',
                searchUrlPattern: 'https://www.linkedin.com/jobs/search/?keywords={keywords}&location={location}',
                logo: 'https://content.linkedin.com/content/dam/me/business/en-us/amp/brand-site/v2/bg/LI-Bug.svg.original.svg',
                apiAvailable: true
            },
            {
                name: 'JobsDB',
                baseUrl: 'https://th.jobsdb.com/',
                searchUrlPattern: 'https://th.jobsdb.com/th/jobs/{keywords}/{location}',
                logo: 'https://th.jobsdb.com/wp-content/themes/jobsdb/img/jobsdb-logo.svg',
                apiAvailable: true
            },
            {
                name: 'JobThai',
                baseUrl: 'https://www.jobthai.com/',
                searchUrlPattern: 'https://www.jobthai.com/th/job/search?q={keywords}&province={location}',
                logo: 'https://www.jobthai.com/assets/img/logo.png',
                apiAvailable: false
            },
            {
                name: 'JobBKK',
                baseUrl: 'https://www.jobbkk.com/',
                searchUrlPattern: 'https://www.jobbkk.com/jobs/list/{keywords}',
                logo: 'https://www.jobbkk.com/img/logo.png',
                apiAvailable: false
            },
            {
                name: 'Job Topgun',
                baseUrl: 'https://www.jobtopgun.com/',
                searchUrlPattern: 'https://www.jobtopgun.com/search?q={keywords}&province={location}',
                logo: 'https://www.jobtopgun.com/assets/images/logo.png',
                apiAvailable: false
            }
        ];
        
        // กำหนดหมวดหมู่งานที่ไม่ใช่แค่ IT
        this.jobCategories = [
            // IT
            'Software Engineer', 'Web Developer', 'Data Scientist', 'IT Support', 'Network Engineer',
            'Database Administrator', 'System Administrator', 'DevOps Engineer', 'QA Engineer', 'UX/UI Designer',
            
            // HR
            'HR Manager', 'Recruitment Officer', 'HR Business Partner', 'HR Consultant', 'Training Specialist',
            'Compensation & Benefits Specialist', 'HR Administrator', 'Talent Acquisition', 'HR Director',
            
            // บัญชี
            'Accountant', 'Financial Analyst', 'Accounting Manager', 'Auditor', 'Tax Consultant',
            'Accounts Payable Clerk', 'Accounts Receivable Clerk', 'Financial Controller', 'Payroll Officer',
            
            // ตรวจสอบภายใน
            'Internal Auditor', 'Compliance Officer', 'Risk Officer', 'Internal Control Specialist',
            'Audit Manager', 'Audit Director', 'Compliance Manager', 'Risk Management Officer',
            
            // การตลาด
            'Marketing Manager', 'Digital Marketing Specialist', 'Content Creator', 'Brand Manager',
            'Marketing Coordinator', 'Social Media Manager', 'SEO Specialist', 'Marketing Director',
            'PR Specialist', 'Event Coordinator', 'Creative Director', 'Product Marketing Manager'
        ];
    }
    
    /**
     * สร้าง URL สำหรับค้นหางานจากคีย์เวิร์ดและตำแหน่งที่ตั้ง
     * @param {string} site ชื่อเว็บไซต์งาน
     * @param {string} keywords คีย์เวิร์ดค้นหา
     * @param {string} location ตำแหน่งที่ตั้ง
     * @returns {string} URL สำหรับค้นหางาน
     */
    generateSearchUrl(site, keywords, location) {
        const jobSite = this.jobSites.find(s => s.name.toLowerCase() === site.toLowerCase());
        if (!jobSite) return null;
        
        // แทนที่พารามิเตอร์ในรูปแบบ URL
        let url = jobSite.searchUrlPattern
            .replace('{keywords}', encodeURIComponent(keywords))
            .replace('{location}', encodeURIComponent(location || ''));
            
        return url;
    }
    
    /**
     * ค้นหางานแบบขนานจากหลายเว็บไซต์
     * @param {string} keywords คีย์เวิร์ดค้นหา
     * @param {string} location ตำแหน่งที่ตั้ง
     * @returns {Array} ผลลัพธ์งานจากหลายเว็บไซต์
     */
    async searchAllJobSites(keywords, location) {
        const searchPromises = this.jobSites.map(site => {
            if (site.apiAvailable) {
                return this.fetchJobsFromApi(site.name, keywords, location);
            } else {
                // สำหรับเว็บไซต์ที่ไม่มี API ให้สร้าง URL แล้วใส่ไว้ในออบเจ็กต์
                const url = this.generateSearchUrl(site.name, keywords, location);
                return Promise.resolve({
                    site: site.name,
                    externalUrl: url,
                    jobs: []
                });
            }
        });
        
        const results = await Promise.all(searchPromises);
        return results.filter(result => result !== null);
    }
    
    /**
     * ดึงข้อมูลงานจาก API (จำลอง)
     * @param {string} site ชื่อเว็บไซต์งาน
     * @param {string} keywords คีย์เวิร์ดค้นหา
     * @param {string} location ตำแหน่งที่ตั้ง
     * @returns {Promise<Object>} ผลลัพธ์การค้นหางาน
     */
    async fetchJobsFromApi(site, keywords, location) {
        try {
            // จำลองการเรียก API สำหรับการสาธิต
            // ในสภาพแวดล้อมจริงนี่จะเป็นการเรียก API จริง
            
            // สร้างข้อมูลงานจำลอง
            const mockJobs = this.generateMockJobs(site, keywords, 10);
            
            // สร้าง URL สำหรับการค้นหาทั้งหมด
            const url = this.generateSearchUrl(site, keywords, location);
            
            return {
                site: site,
                externalUrl: url,
                jobs: mockJobs
            };
        } catch (error) {
            console.error(`Error fetching jobs from ${site}:`, error);
            return null;
        }
    }
    
    /**
     * สร้างข้อมูลงานจำลอง
     * @param {string} site ชื่อเว็บไซต์งาน
     * @param {string} keywords คีย์เวิร์ดค้นหา
     * @param {number} count จำนวนงานที่ต้องการ
     * @returns {Array} งานจำลอง
     */
    generateMockJobs(site, keywords, count) {
        const jobs = [];
        
        // แบ่งคีย์เวิร์ดเป็นคำสำคัญแต่ละคำ
        const keywordArray = keywords.split(/\s+/);
        
        // หาตำแหน่งงานที่ตรงกับคีย์เวิร์ด
        const matchingCategories = this.jobCategories.filter(category => 
            keywordArray.some(keyword => 
                category.toLowerCase().includes(keyword.toLowerCase())
            )
        );
        
        // ถ้าไม่มีตำแหน่งงานที่ตรงกัน ให้ใช้ทั้งหมด
        const categoriesToUse = matchingCategories.length > 0 ? matchingCategories : this.jobCategories;
        
        const companies = [
            'Google Thailand', 'Microsoft (Thailand)', 'Agoda', 'LINE Thailand', 'Shopee',
            'Lazada', 'SCB', 'Krungthai Bank', 'PTT', 'Central Group',
            'True Corporation', 'AIS', 'DTAC', 'Thai Airways', 'Bangkok Bank',
            'CP Group', 'King Power', 'Minor Group', 'The Mall Group', 'DKSH Thailand'
        ];
        
        const locations = [
            'Bangkok', 'Nonthaburi', 'Pathum Thani', 'Chiang Mai', 'Phuket',
            'Chonburi', 'Rayong', 'Khon Kaen', 'Hat Yai', 'Pattaya'
        ];
        
        // สร้างงานจำลอง
        for (let i = 0; i < count; i++) {
            const categoryIndex = Math.floor(Math.random() * categoriesToUse.length);
            const companyIndex = Math.floor(Math.random() * companies.length);
            const locationIndex = Math.floor(Math.random() * locations.length);
            
            const salaryMin = 30000 + Math.floor(Math.random() * 50000);
            const salaryMax = salaryMin + 20000 + Math.floor(Math.random() * 30000);
            
            const job = {
                id: `${site.toLowerCase()}-${i + 1}`,
                title: categoriesToUse[categoryIndex],
                company: companies[companyIndex],
                location: locations[locationIndex],
                salary: `฿${salaryMin.toLocaleString()} - ฿${salaryMax.toLocaleString()}`,
                posted: `${Math.floor(Math.random() * 7) + 1} days ago`,
                description: `We are looking for a talented ${categoriesToUse[categoryIndex]} to join our team at ${companies[companyIndex]}. This is an excellent opportunity to work with cutting-edge technology.`,
                url: this.generateSearchUrl(site, categoriesToUse[categoryIndex], locations[locationIndex]),
                source: site
            };
            
            jobs.push(job);
        }
        
        return jobs;
    }
    
    /**
     * จับคู่งานจากเว็บไซต์จริงกับ Resume
     * @param {Object} resumeData ข้อมูล Resume
     * @returns {Promise<Array>} รายการงานที่เหมาะสม
     */
    async matchResumeWithRealJobs(resumeData) {
        try {
            // สร้างคำค้นหาจากทักษะและประสบการณ์ใน Resume
            const keywords = resumeData.skills.slice(0, 3).join(' ') + ' ' + resumeData.mostRecentRole;
            
            // ค้นหางานจากเว็บไซต์ต่างๆ
            const results = await this.searchAllJobSites(keywords, '');
            
            // รวมงานจากทุกเว็บไซต์
            const allJobs = [];
            
            for (const result of results) {
                // เพิ่มงานที่มาจาก API
                allJobs.push(...result.jobs.map(job => ({
                    ...job,
                    externalUrl: job.url,
                    source: result.site
                })));
                
                // เพิ่มลิงก์ไปยังเว็บไซต์งานโดยตรง
                if (result.externalUrl) {
                    allJobs.push({
                        id: `${result.site.toLowerCase()}-all`,
                        title: `Browse All ${keywords} Jobs on ${result.site}`,
                        company: result.site,
                        description: `View all matching jobs for your skills on ${result.site}.`,
                        externalUrl: result.externalUrl,
                        source: result.site,
                        isBrowseAll: true
                    });
                }
            }
            
            return allJobs;
        } catch (error) {
            console.error('Error matching resume with real jobs:', error);
            return [];
        }
    }
}

// สร้างอินสแตนซ์สำหรับใช้งาน
const jobSiteConnector = new JobSiteConnector();