/**
 * Synthetic Data Generator for AI Matching
 * สร้างข้อมูลสังเคราะห์สำหรับโมเดล AI Matching
 */

class SyntheticDataGenerator {
    constructor() {
        // กำหนดรายการทักษะ 13 ตัวอย่าง
        this.skillsList = [
            'python', 'java', 'javascript', 'sql', 'machine learning',
            'react', 'node.js', 'spring', 'mongodb', 'mysql',
            'data analysis', 'statistics', 'deep learning'
        ];
        
        // กำหนดตำแหน่งงาน 5 ตำแหน่ง พร้อมทักษะที่ต้องการ ประสบการณ์ขั้นต่ำ และการศึกษาขั้นต่ำ
        this.predefinedJobs = [
            {
                id: 'j1',
                title: 'Data Scientist',
                requiredSkills: ['python', 'machine learning', 'sql'],
                minExp: 2,
                minEdu: 'Bachelor'
            },
            {
                id: 'j2',
                title: 'Backend Developer',
                requiredSkills: ['java', 'spring', 'mysql'],
                minExp: 3,
                minEdu: 'Bachelor'
            },
            {
                id: 'j3',
                title: 'Frontend Developer',
                requiredSkills: ['javascript', 'react', 'html', 'css'],
                minExp: 2,
                minEdu: 'Bachelor'
            },
            {
                id: 'j4',
                title: 'Data Analyst',
                requiredSkills: ['python', 'sql', 'data analysis', 'statistics'],
                minExp: 1,
                minEdu: 'Bachelor'
            },
            {
                id: 'j5',
                title: 'Fullstack Developer',
                requiredSkills: ['javascript', 'node.js', 'react', 'mongodb'],
                minExp: 4,
                minEdu: 'Bachelor'
            }
        ];
        
        // กำหนดตำแหน่งงานเพิ่มเติมจาก LinkedIn (ไม่ใช่แค่ IT)
        this.additionalJobs = [
            {
                id: 'j6',
                title: 'Marketing Manager',
                requiredSkills: ['digital marketing', 'social media', 'content strategy', 'analytics'],
                minExp: 3,
                minEdu: 'Bachelor'
            },
            {
                id: 'j7',
                title: 'Financial Analyst',
                requiredSkills: ['financial modeling', 'excel', 'data analysis', 'statistics'],
                minExp: 2,
                minEdu: 'Bachelor'
            },
            {
                id: 'j8',
                title: 'HR Specialist',
                requiredSkills: ['recruitment', 'hr policies', 'compensation', 'employee relations'],
                minExp: 1,
                minEdu: 'Bachelor'
            },
            {
                id: 'j9',
                title: 'Project Manager',
                requiredSkills: ['project management', 'agile', 'leadership', 'communication'],
                minExp: 3,
                minEdu: 'Bachelor'
            },
            {
                id: 'j10',
                title: 'Sales Representative',
                requiredSkills: ['sales', 'negotiation', 'customer service', 'crm'],
                minExp: 1,
                minEdu: 'Bachelor'
            }
        ];
        
        // รวมตำแหน่งงานทั้งหมด
        this.allJobs = [...this.predefinedJobs, ...this.additionalJobs];
        
        // กำหนดสกิลเพิ่มเติมสำหรับงานที่ไม่ใช่ IT
        this.additionalSkills = [
            'digital marketing', 'social media', 'content strategy', 'analytics',
            'financial modeling', 'excel', 'recruitment', 'hr policies',
            'compensation', 'employee relations', 'project management', 'agile',
            'leadership', 'communication', 'sales', 'negotiation', 'customer service',
            'crm', 'html', 'css'
        ];
        
        // รวมทักษะทั้งหมด
        this.allSkills = [...this.skillsList, ...this.additionalSkills];
        
        // กำหนดระดับการศึกษา
        this.educationLevels = ['Bachelor', 'Master', 'PhD'];
    }
    
    /**
     * สร้างเรซูเม่สังเคราะห์
     * @param {number} count จำนวนเรซูเม่ที่ต้องการสร้าง
     * @returns {Array} รายการเรซูเม่สังเคราะห์
     */
    generateResumes(count = 300) {
        const resumes = [];
        
        for (let i = 0; i < count; i++) {
            // สุ่มจำนวนทักษะ (2-5 ทักษะ)
            const skillCount = 2 + Math.floor(Math.random() * 4);
            // สุ่มเลือกทักษะ
            const skills = this.getRandomSkills(skillCount);
            // สุ่มประสบการณ์ (0-10 ปี)
            const yearsExp = Math.floor(Math.random() * 11);
            // สุ่มระดับการศึกษา
            const education = this.educationLevels[Math.floor(Math.random() * this.educationLevels.length)];
            
            // สร้างข้อความเรซูเม่
            const text = `${education} graduate with ${yearsExp} years of experience in ${skills.join(', ')}.`;
            
            // คำนวณความยาวเรซูเม่และความยาวเฉลี่ยของคำ
            const words = text.split(' ');
            const resumeLen = words.length;
            const avgWordLen = text.replace(/[.,]/g, '').length / resumeLen;
            
            // สร้างเรซูเม่
            const resume = {
                id: `r${i + 1}`,
                skills: skills,
                yearsExp: yearsExp,
                education: education,
                text: text,
                resumeLen: resumeLen,
                avgWordLen: avgWordLen,
                eduOrd: this.getEducationOrdinal(education)
            };
            
            resumes.push(resume);
        }
        
        return resumes;
    }
    
    /**
     * แปลงระดับการศึกษาเป็นค่าตัวเลข
     * @param {string} education ระดับการศึกษา
     * @returns {number} ค่าตัวเลขของระดับการศึกษา
     */
    getEducationOrdinal(education) {
        switch (education) {
            case 'Bachelor': return 1;
            case 'Master': return 2;
            case 'PhD': return 3;
            default: return 0;
        }
    }
    
    /**
     * สุ่มเลือกทักษะจากรายการทักษะทั้งหมด
     * @param {number} count จำนวนทักษะที่ต้องการ
     * @returns {Array} รายการทักษะที่สุ่มได้
     */
    getRandomSkills(count) {
        // สร้าง copy ของ array ทักษะเพื่อไม่ให้กระทบกับต้นฉบับ
        const allSkillsCopy = [...this.allSkills];
        const selectedSkills = [];
        
        // สุ่มเลือกทักษะตามจำนวนที่ต้องการ
        for (let i = 0; i < count && allSkillsCopy.length > 0; i++) {
            const randomIndex = Math.floor(Math.random() * allSkillsCopy.length);
            selectedSkills.push(allSkillsCopy[randomIndex]);
            allSkillsCopy.splice(randomIndex, 1); // ลบทักษะที่เลือกแล้วออกจากรายการ
        }
        
        return selectedSkills;
    }
    
    /**
     * คำนวณค่า Jaccard Similarity ระหว่างสองเซตของทักษะ
     * @param {Array} setA เซตแรก
     * @param {Array} setB เซตที่สอง
     * @returns {number} ค่า Jaccard Similarity
     */
    calculateJaccardSimilarity(setA, setB) {
        // แปลงเป็น Set เพื่อหาจำนวนสมาชิกที่ไม่ซ้ำกัน
        const a = new Set(setA);
        const b = new Set(setB);
        
        // หาจำนวนสมาชิกที่อยู่ในทั้งสองเซต (intersection)
        const intersection = new Set([...a].filter(x => b.has(x)));
        
        // หาจำนวนสมาชิกทั้งหมดโดยไม่นับซ้ำ (union)
        const union = new Set([...a, ...b]);
        
        // คำนวณ Jaccard Similarity = |A ∩ B| / |A ∪ B|
        return intersection.size / union.size;
    }
    
    /**
     * คำนวณจำนวนทักษะที่ขาดไป
     * @param {Array} resumeSkills ทักษะในเรซูเม่
     * @param {Array} jobSkills ทักษะที่ต้องการในงาน
     * @returns {number} จำนวนทักษะที่ขาดไป
     */
    calculateMissingSkills(resumeSkills, jobSkills) {
        // แปลงเป็น Set
        const resumeSkillsSet = new Set(resumeSkills);
        const jobSkillsSet = new Set(jobSkills);
        
        // หาทักษะที่ขาดไป = jobSkills - resumeSkills
        const missingSkills = [...jobSkillsSet].filter(skill => !resumeSkillsSet.has(skill));
        
        return missingSkills.length;
    }
    
    /**
     * คำนวณค่า TF-IDF Cosine Similarity
     * (ในจาวาสคริปต์เราจำลองคำนวณแบบง่ายๆ)
     * @param {string} resumeText ข้อความในเรซูเม่
     * @param {string} jobText ข้อความในงาน
     * @returns {number} ค่า Cosine Similarity
     */
    calculateTFIDFCosineSimilarity(resumeText, jobText) {
        // แปลงข้อความเป็นตัวพิมพ์เล็กและแยกคำ
        const resumeWords = resumeText.toLowerCase().split(/\W+/).filter(w => w.length > 0);
        const jobWords = jobText.toLowerCase().split(/\W+/).filter(w => w.length > 0);
        
        // นับจำนวนคำซ้ำ
        const resumeWordCount = this.countWords(resumeWords);
        const jobWordCount = this.countWords(jobWords);
        
        // หาคำที่มีในทั้งสองเอกสาร
        const commonWords = Object.keys(resumeWordCount).filter(word => jobWordCount[word]);
        
        // คำนวณ dot product
        let dotProduct = 0;
        for (const word of commonWords) {
            dotProduct += resumeWordCount[word] * jobWordCount[word];
        }
        
        // คำนวณ magnitude ของแต่ละเวกเตอร์
        const resumeMagnitude = Math.sqrt(Object.values(resumeWordCount).reduce((sum, count) => sum + count * count, 0));
        const jobMagnitude = Math.sqrt(Object.values(jobWordCount).reduce((sum, count) => sum + count * count, 0));
        
        // คำนวณ cosine similarity
        if (resumeMagnitude === 0 || jobMagnitude === 0) return 0;
        return dotProduct / (resumeMagnitude * jobMagnitude);
    }
    
    /**
     * นับจำนวนคำในรายการ
     * @param {Array} words รายการคำ
     * @returns {Object} object ที่มี key เป็นคำและ value เป็นจำนวนครั้งที่พบ
     */
    countWords(words) {
        const wordCount = {};
        for (const word of words) {
            wordCount[word] = (wordCount[word] || 0) + 1;
        }
        return wordCount;
    }
    
    /**
     * กำหนดป้ายกำกับ (Match/Not Match) ตามเงื่อนไข
     * @param {Object} resume เรซูเม่
     * @param {Object} job งาน
     * @returns {number} 1 คือ Match, 0 คือ Not Match
     */
    assignMatchLabel(resume, job) {
        // คำนวณ Jaccard Similarity
        const jaccardSimilarity = this.calculateJaccardSimilarity(resume.skills, job.requiredSkills);
        
        // เงื่อนไขการ Match: ประสบการณ์ >= min_exp และ Jaccard >= 0.4 และ ระดับการศึกษา >= min_edu
        const expCondition = resume.yearsExp >= job.minExp;
        const jaccardCondition = jaccardSimilarity >= 0.4;
        const eduCondition = this.getEducationOrdinal(resume.education) >= this.getEducationOrdinal(job.minEdu);
        
        return (expCondition && jaccardCondition && eduCondition) ? 1 : 0;
    }
    
    /**
     * สร้างชุดข้อมูล Pairs สำหรับโมเดล
     * @param {Array} resumes รายการเรซูเม่
     * @param {Array} jobs รายการงาน
     * @returns {Array} ชุดข้อมูล pairs ที่มีทั้ง features และ label
     */
    generatePairs(resumes, jobs) {
        const pairs = [];
        
        // จับคู่แต่ละเรซูเม่กับแต่ละงาน
        for (const resume of resumes) {
            for (const job of jobs) {
                // สร้าง job text
                const jobText = `${job.title} requiring ${job.requiredSkills.join(', ')} with minimum ${job.minExp} years of experience and ${job.minEdu} degree.`;
                
                // คำนวณ features
                const cosSim = this.calculateTFIDFCosineSimilarity(resume.text, jobText);
                const jaccardSkill = this.calculateJaccardSimilarity(resume.skills, job.requiredSkills);
                const missingSkills = this.calculateMissingSkills(resume.skills, job.requiredSkills);
                
                // กำหนด label
                const label = this.assignMatchLabel(resume, job);
                
                // สร้าง pair
                const pair = {
                    resumeId: resume.id,
                    jobId: job.id,
                    features: {
                        cosSim: cosSim,
                        jaccardSkill: jaccardSkill,
                        missingSkills: missingSkills,
                        yearsExp: resume.yearsExp,
                        eduOrd: resume.eduOrd,
                        resumeLen: resume.resumeLen,
                        avgWordLen: resume.avgWordLen
                    },
                    label: label
                };
                
                pairs.push(pair);
            }
        }
        
        return pairs;
    }
    
    /**
     * สร้างข้อมูลทั้งหมดพร้อมใช้งาน
     * @returns {Object} ข้อมูลทั้งหมด
     */
    generateAllData() {
        // สร้างเรซูเม่ 300 รายการ
        const resumes = this.generateResumes(300);
        
        // สร้าง pairs ระหว่างเรซูเม่และงาน
        const pairs = this.generatePairs(resumes, this.allJobs);
        
        return {
            resumes: resumes,
            jobs: this.allJobs,
            pairs: pairs
        };
    }
}

// สร้าง instance ของ SyntheticDataGenerator
const syntheticDataGenerator = new SyntheticDataGenerator();