/**
 * Gemini AI Search Integration (English Version)
 * This module provides AI-powered search functionality using Google's Gemini model
 */

class GeminiSearchEN {
    constructor() {
        // Configuration for Gemini API (Note: In a real implementation, API keys would be stored securely server-side)
        this.apiKey = 'SIMULATED_GEMINI_API_KEY';
        this.apiEndpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
        
        // Search state
        this.isSearching = false;
        this.lastQuery = '';
        this.searchResults = [];
        this.suggestedQueries = [
            'Software Developer',
            'Data Analyst', 
            'Computer Engineer',
            'Digital Marketing Manager',
            'UX/UI Designer',
            'SEO Specialist',
            'Content Writer',
            'Mobile App Developer'
        ];

        // Bind methods
        this.init = this.init.bind(this);
        this.search = this.search.bind(this);
        this.handleSearchInput = this.handleSearchInput.bind(this);
        this.renderSuggestions = this.renderSuggestions.bind(this);
        this.simulateGeminiResponse = this.simulateGeminiResponse.bind(this);
    }

    /**
     * Initialize the Gemini search
     * @param {string} searchContainerId - ID of the search container element
     * @param {string} resultContainerId - ID of the result container element (optional)
     */
    init(searchContainerId, resultContainerId = null) {
        // Get DOM elements
        this.searchContainer = document.getElementById(searchContainerId);
        this.resultContainer = resultContainerId ? document.getElementById(resultContainerId) : null;
        
        if (!this.searchContainer) {
            console.error('Search container not found:', searchContainerId);
            return;
        }
        
        // Create search UI
        this.createSearchUI();
        
        // Bind events
        this.bindEvents();
        
        // Render initial suggestions
        this.renderSuggestions();
        
        console.log('Gemini Search (EN) initialized');
    }
    
    /**
     * Create the search UI elements
     */
    createSearchUI() {
        // Create search form
        const searchForm = document.createElement('form');
        searchForm.className = 'ai-search-box';
        searchForm.onsubmit = (e) => {
            e.preventDefault();
            this.search(this.searchInput.value);
        };
        
        // Create search input
        this.searchInput = document.createElement('input');
        this.searchInput.type = 'text';
        this.searchInput.className = 'ai-search-input';
        this.searchInput.placeholder = 'Search for jobs you want with AI...';
        this.searchInput.autocomplete = 'off';
        
        // Create search button
        this.searchButton = document.createElement('button');
        this.searchButton.type = 'submit';
        this.searchButton.className = 'ai-search-button';
        this.searchButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
        
        // Create suggestions container
        this.suggestionsContainer = document.createElement('div');
        this.suggestionsContainer.className = 'ai-search-suggestions';
        
        // Append elements to form
        searchForm.appendChild(this.searchInput);
        searchForm.appendChild(this.searchButton);
        
        // Append form and suggestions to container
        this.searchContainer.appendChild(searchForm);
        this.searchContainer.appendChild(this.suggestionsContainer);
    }
    
    /**
     * Bind event listeners
     */
    bindEvents() {
        this.searchInput.addEventListener('input', this.handleSearchInput);
        
        // Add click event for suggestion tags
        this.suggestionsContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('ai-suggestion-tag')) {
                const query = e.target.textContent;
                this.searchInput.value = query;
                this.search(query);
            }
        });
    }
    
    /**
     * Handle search input changes
     * @param {Event} e - Input event
     */
    handleSearchInput(e) {
        const query = e.target.value.trim();
        
        // Update search button state
        this.searchButton.disabled = query.length === 0;
        
        if (query.length > 2 && query !== this.lastQuery) {
            // Auto-suggest would happen here in a real implementation
        }
    }
    
    /**
     * Render search suggestions
     */
    renderSuggestions() {
        this.suggestionsContainer.innerHTML = '';
        
        // Create elements for each suggestion
        this.suggestedQueries.forEach(query => {
            const tag = document.createElement('a');
            tag.className = 'ai-suggestion-tag';
            tag.textContent = query;
            tag.href = '#';
            tag.onclick = (e) => {
                e.preventDefault();
                this.searchInput.value = query;
                this.search(query);
            };
            
            this.suggestionsContainer.appendChild(tag);
        });
    }
    
    /**
     * Perform a search with Gemini
     * @param {string} query - Search query
     */
    async search(query) {
        if (!query || this.isSearching) return;
        
        query = query.trim();
        if (query.length === 0) return;
        
        this.lastQuery = query;
        this.isSearching = true;
        
        // Update UI to show loading state
        this.searchButton.innerHTML = '<div class="loading-spinner"></div>';
        this.searchButton.disabled = true;
        
        try {
            // In a real implementation, this would call the Gemini API
            // For this demo, we'll simulate a response
            const response = await this.simulateGeminiResponse(query);
            
            // Process and display results
            this.processResults(response);
        } catch (error) {
            console.error('Search error:', error);
            
            // Show error in result container if available
            if (this.resultContainer) {
                this.resultContainer.innerHTML = `
                    <div class="search-error">
                        <p>Sorry, an error occurred during search. Please try again.</p>
                    </div>
                `;
            }
        } finally {
            // Reset UI
            this.isSearching = false;
            this.searchButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
            this.searchButton.disabled = false;
        }
    }
    
    /**
     * Process search results
     * @param {Object} response - API response
     */
    processResults(response) {
        // Store results
        this.searchResults = response.results;
        
        // Trigger custom event
        const event = new CustomEvent('geminiSearchComplete', {
            detail: {
                query: this.lastQuery,
                results: this.searchResults
            }
        });
        document.dispatchEvent(event);
        
        // If result container is available, render results
        if (this.resultContainer) {
            this.renderResults();
        }
    }
    
    /**
     * Render search results
     */
    renderResults() {
        if (!this.resultContainer || !this.searchResults.length) return;
        
        this.resultContainer.innerHTML = '';
        
        // Create header
        const header = document.createElement('div');
        header.className = 'search-results-header';
        header.innerHTML = `<h3>AI Search Results for: "${this.lastQuery}"</h3>`;
        this.resultContainer.appendChild(header);
        
        // Create results list
        const resultsList = document.createElement('div');
        resultsList.className = 'search-results-list';
        
        // Add each result
        this.searchResults.forEach(result => {
            const resultItem = document.createElement('div');
            resultItem.className = 'search-result-item';
            resultItem.innerHTML = `
                <h4>${result.title}</h4>
                <p>${result.description}</p>
                <div class="result-meta">
                    <span class="result-category">${result.category}</span>
                    <span class="result-match">${result.matchScore}% match with search</span>
                </div>
                <a href="${result.url}" class="btn-primary">View Details</a>
            `;
            resultsList.appendChild(resultItem);
        });
        
        this.resultContainer.appendChild(resultsList);
    }
    
    /**
     * Simulate a response from Gemini API (for demonstration)
     * @param {string} query - Search query
     * @returns {Promise<Object>} Simulated response
     */
    async simulateGeminiResponse(query) {
        // Simulate network latency
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Generate random match scores
        const getRandomScore = () => 70 + Math.floor(Math.random() * 30);
        
        // Map categories to related job titles
        const categoryMap = {
            'Software': ['Software Developer', 'Full Stack Developer', 'Backend Developer', 'Frontend Developer'],
            'Data': ['Data Analyst', 'Data Scientist', 'Data Engineer', 'Business Analyst'],
            'Marketing': ['Digital Marketing Manager', 'SEO Specialist', 'Content Marketing', 'Social Media Manager'],
            'Design': ['UX/UI Designer', 'Graphic Designer', 'Product Designer', 'Web Designer'],
            'Engineering': ['Software Engineer', 'DevOps Engineer', 'System Administrator', 'Cloud Engineer'],
            'Management': ['Project Manager', 'Product Manager', 'Team Lead', 'Technical Lead']
        };
        
        // Determine relevant categories based on query
        const relevantCategories = Object.keys(categoryMap).filter(category => 
            query.toLowerCase().includes(category.toLowerCase()) || 
            categoryMap[category].some(job => 
                query.toLowerCase().includes(job.toLowerCase())
            )
        );
        
        // If no specific categories match, include a mix
        const categoriesToUse = relevantCategories.length > 0 
            ? relevantCategories 
            : Object.keys(categoryMap).slice(0, 3);
        
        // Generate results
        const results = [];
        
        categoriesToUse.forEach(category => {
            const jobTitles = categoryMap[category];
            
            // Add 2-3 results per category
            const numResults = 2 + Math.floor(Math.random() * 2);
            
            for (let i = 0; i < numResults; i++) {
                const jobTitle = jobTitles[i % jobTitles.length];
                const matchScore = getRandomScore();
                
                results.push({
                    title: `${jobTitle} - Professional Opportunity`,
                    description: `${jobTitle} position with ${3 + Math.floor(Math.random() * 5)} years experience required. Professional growth opportunities in ${category} field.`,
                    category: category,
                    matchScore: matchScore,
                    url: '#',
                    relevance: matchScore
                });
            }
        });
        
        // Sort by relevance
        results.sort((a, b) => b.relevance - a.relevance);
        
        return {
            results: results,
            suggestedQueries: [
                query + ' entry level',
                query + ' senior position',
                query + ' remote work',
                'recommended ' + query
            ]
        };
    }
}

// Initialize and export
const geminiSearchEN = new GeminiSearchEN();

// Make available globally
window.geminiSearchEN = geminiSearchEN;