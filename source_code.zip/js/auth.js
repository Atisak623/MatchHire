// Authentication Functions
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    checkLoginStatus();

    // Handle login form submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            login();
        });
    }

    // Handle registration form submission
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            register();
        });
    }

    // Handle logout
    const logoutButton = document.getElementById('logout-btn');
    if (logoutButton) {
        logoutButton.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
});

// Check login status and update UI accordingly
function checkLoginStatus() {
    const currentUser = localStorage.getItem('currentUser');
    const loginButton = document.querySelector('.login-btn');
    const registerButton = document.querySelector('.register-btn');
    const userDisplay = document.querySelector('.user-display');
    const logoutButton = document.getElementById('logout-btn');
    const profileLink = document.querySelector('.profile-link');

    if (currentUser) {
        // User is logged in
        const user = JSON.parse(currentUser);
        
        // Hide login/register buttons
        if (loginButton) loginButton.style.display = 'none';
        if (registerButton) registerButton.style.display = 'none';
        
        // Show user display and logout button
        if (userDisplay) {
            userDisplay.style.display = 'flex';
            userDisplay.querySelector('.username').textContent = user.name;
        }
        if (logoutButton) logoutButton.style.display = 'block';
        if (profileLink) profileLink.style.display = 'block';
        
        // Update navigation if needed
        updateNavForLoggedInUser(user.type);
    } else {
        // User is not logged in
        if (loginButton) loginButton.style.display = 'block';
        if (registerButton) registerButton.style.display = 'block';
        if (userDisplay) userDisplay.style.display = 'none';
        if (logoutButton) logoutButton.style.display = 'none';
        if (profileLink) profileLink.style.display = 'none';
    }
}

// Update navigation based on user type
function updateNavForLoggedInUser(userType) {
    const applyJobLink = document.querySelector('.apply-job-link');
    const postJobLink = document.querySelector('.post-job-link');
    
    if (userType === 'seeker') {
        // Job seeker specific UI
        if (applyJobLink) applyJobLink.style.display = 'block';
        if (postJobLink) postJobLink.style.display = 'none';
    } else if (userType === 'employer') {
        // Employer specific UI
        if (applyJobLink) applyJobLink.style.display = 'none';
        if (postJobLink) postJobLink.style.display = 'block';
    }
}

// Login function
function login() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Get users from localStorage
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Find user
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Store current user in localStorage
        localStorage.setItem('currentUser', JSON.stringify(user));
        
        // Show success message
        alert('เข้าสู่ระบบสำเร็จ! ยินดีต้อนรับกลับ ' + user.name);
        
        // Redirect to home page
        window.location.href = 'index.html';
    } else {
        // Show error message
        document.getElementById('login-error').textContent = 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
    }
}

// Register function
function register() {
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    const userType = document.getElementById('user-type-hidden').value;
    
    // Validate passwords match
    if (password !== confirmPassword) {
        document.getElementById('register-error').textContent = 'รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน';
        return;
    }
    
    // Get existing users
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Check if email already exists
    if (users.some(user => user.email === email)) {
        document.getElementById('register-error').textContent = 'อีเมลนี้มีผู้ใช้งานแล้ว';
        return;
    }
    
    // Create new user
    const newUser = {
        id: Date.now().toString(),
        name,
        email,
        password,
        type: userType,
        resume: null,
        createdAt: new Date().toISOString()
    };
    
    // Add to users array
    users.push(newUser);
    
    // Save to localStorage
    localStorage.setItem('users', JSON.stringify(users));
    
    // Login the new user
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    
    // Show success message
    alert('ลงทะเบียนสำเร็จ! ยินดีต้อนรับ ' + name);
    
    // Redirect based on user type
    if (userType === 'seeker') {
        window.location.href = 'profile.html';
    } else {
        window.location.href = 'employer-dashboard.html';
    }
}

// Logout function
function logout() {
    localStorage.removeItem('currentUser');
    alert('ออกจากระบบสำเร็จ');
    window.location.href = 'index.html';
}